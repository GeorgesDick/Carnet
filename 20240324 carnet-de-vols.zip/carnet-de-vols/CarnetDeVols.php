<?php
/*
Plugin Name: Carnet de vols
Plugin URI: http://cap83.org/
Description: Ce plugin permet de gérer un carnet de vols, multi-ULM et multi-pilotes.
Version: 1.8c
Author: Georges
Author URI: http://georgesdick.com/
*/


if (!defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Le niveau admin pour voir les comptes des autres pilotes
$niveauListAll = 1;
// Le niveau admin "trésorier" (peut gérer les comptes des pilotes)
$niveauTresorier = 2;
// Le niveau admin "vol mécano" (peut faire un vol sans le payer (e.g. pour vérifications après intervention mécanicien))
$niveauMecano = 4;
// Le flag "vol mécano" (à true par défaut)
$volMecanoFlag = 1;
// Le nombre maximal de lignes à afficher
$nbMaxAff = 25;
// Ajout automatique du montant de la note de frais  (à true par défaut)
$autoAjoutNoteDeFrais = 1;
// Les valeurs des différentes tables pour les fichiers téléchargés
$tableNotesDeFrais = 0;
$tableEntretien = 1;
// Valeur par défaut pour le nombre de mois affichés dans la liste des pilotes
$nombreMoisPrec = 3;
// La liste des valeurs possibles pour plein_complet
$plein_complet_liste = array('non', 'avant', 'apres');
$plein_complet_liste_texte = array('Non', 'Avant le vol', 'Apr&egrave;s le vol');

// Créer les tables de base de données pour stocker les informations
function gd_carnet_create_table() {
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	
	// Table de pré-remplissage des motifs de gestion des comptes des pilotes
	$table_name = $wpdb->prefix . 'gd_table_motifs_comptes';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		motif varchar(255) NOT NULL,
		actif BOOLEAN NOT NULL DEFAULT TRUE,
		PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);

	// Table des carnets d'entretien des ULMs
	$table_name = $wpdb->prefix . 'gd_table_entretien';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		ulm mediumint(9) NOT NULL,
        date_reparation date NOT NULL,
		horametre_debut int(11) NOT NULL,
		horametre_fin int(11) NOT NULL,
		mecano text,
		objet text,
		nature text,
		reste text,
		resultat text,
		saisi_par mediumint(9) NOT NULL,
		facture VARCHAR(200) NULL,
		date_creation timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
	
	// Table des vols
	$table_name = $wpdb->prefix . 'gd_table_vols';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		pilote mediumint(9) NOT NULL,
		flags mediumint(9),
		ulm mediumint(9) NOT NULL,
        date_vol date NOT NULL,
		heure_depart time NOT NULL,
		heure_arrivee time NOT NULL,
		horametre_depart int(11) NOT NULL,
		horametre_arrivee int(11) NOT NULL,
		minutes_de_vol mediumint(9) NOT NULL,
		cout_du_vol FLOAT NOT NULL DEFAULT '0.0',
		terrain_depart_oaci char(9) NOT NULL,
		terrain_arrivee_oaci char(9) NOT NULL,
		carburant_depart mediumint(9) NOT NULL,
		carburant_arrivee mediumint(9) NOT NULL,
		carburant_ajoute mediumint(9) NOT NULL DEFAULT 0,
		plein_complet` ENUM('non','avant','apres') NOT NULL DEFAULT 'non',
		remarques text,
		notes_pilote text,
		derniere_modification timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
		date_creation timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
	
	// Table des ULMs
	$table_name = $wpdb->prefix . 'gd_table_ulm';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		immatriculation varchar(200) NOT NULL,
		modele varchar(200) NOT NULL,
		actif boolean NOT NULL DEFAULT TRUE,
		tarif_heure smallint(3) NOT NULL DEFAULT 0,
		remarques text,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
	
	// Table des pilotes
	$table_name = $wpdb->prefix . 'gd_table_pilote';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		actif BOOLEAN NOT NULL DEFAULT TRUE,
		user_login varchar(50),
		nom_pilote varchar(200) NOT NULL,
		brevet varchar(50) NOT NULL,
		lache boolean NOT NULL,
		date_lache date NOT NULL,
		emport boolean NOT NULL,
		date_emport date NOT NULL,
		niveau_admin mediumint(9),
		remarques text,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);
	
	// Liste des aérodromes avec code OACI
	$table_name = $wpdb->prefix . 'gd_table_oaci';
	// Cette table doit toujours être vide et re-remplie lors d'une activation de cette extension
	$sql = "DROP TABLE IF EXISTS $table_name";
	$wpdb->query($sql);
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		departement char(3) NOT NULL,
		nom text NOT NULL,
		commune text NOT NULL,
		iata char(5),
		oaci char(6) NOT NULL,
		altitude smallint(3),
		nb_pistes tinyint(3),
		remarques text,
        PRIMARY KEY (id),
		INDEX(oaci)
    ) $charset_collate;";
    dbDelta($sql);
	
	// Comptes des pilotes
	$table_name = $wpdb->prefix . 'gd_table_pilote_comptes';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		pilote mediumint(9) NOT NULL,
		auteur mediumint(9) NOT NULL,
		motif varchar(255) NOT NULL,
        credit decimal(12,2) NOT NULL,
        debit decimal(12,2) NOT NULL,
		id_vol mediumint(9),
		id_frais mediumint(9),
        date date NOT NULL,
		PRIMARY KEY (id)
	) $charset_collate;";
	dbDelta($sql);
	
	// Liens pilotes -> ULM (qui est lâché sur quel appareil ?)
	$table_name = $wpdb->prefix . 'gd_table_pilote_ulm_lache';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		pilote mediumint(9) NOT NULL,
		ulm mediumint(9) NOT NULL,
		date_lache DATE NOT NULL,
		PRIMARY KEY (id)
	) $charset_collate;";
	dbDelta($sql);
	
	// Table des fichiers téléchargés (notes de frais, entretiens, etc.)
	$table_name = $wpdb->prefix . 'gd_table_fichiers';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		clef_autre mediumint(9) NOT NULL,
		table_autre mediumint(9) NOT NULL DEFAULT 0,
		fichier VARCHAR(200) NULL,
		description varchar(255) NOT NULL,
		PRIMARY KEY (id)
	) $charset_collate;";
	dbDelta($sql);
	
	// Table des notes de frais
	$table_name = $wpdb->prefix . 'gd_table_frais';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
		valide BOOLEAN NOT NULL DEFAULT TRUE,
		pilote mediumint(9) NOT NULL,
		description text NOT NULL,
		valeur decimal(12,2) NOT NULL,
		date_note timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (id)
	) $charset_collate;";
	dbDelta($sql);
	
	gd_carnet_fill_oaci_airports();			// Remplissage de la liste des aérodromes OACI
	gd_carnet_pre_fill_motifs_comptes();	// Pré-remplissage des motifs de la table des comptes
}

// Lecture de la table des aérodromes pour remplir la base
function gd_carnet_fill_oaci_airports() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'gd_table_oaci';
	
	$csvFile = __DIR__ . '\oaci_tab_ok.csv';
	
	if (($handle = fopen($csvFile, 'r')) !== false) {
		// Ignorer la première ligne (en-têtes de colonne)
		fgetcsv($handle);
		// Parcourir les lignes du fichier CSV
		while (($data = fgetcsv($handle,500,";","\"","\\")) !== false) {
			$uneLigneSQL= 'INSERT INTO ' . $table_name . ' (departement, nom, commune, iata, oaci, altitude, nb_pistes, remarques) VALUES ("' .  $data[0] . '", "' .  $data[1] . '","' .  $data[2] . '","' .  $data[3] . '","' .  $data[4] . '",' .  $data[5] . ',' .  $data[6] . ',"' .  $data[7] . '")';
			dbDelta($uneLigneSQL);
			}
		fclose($handle);
		}
}

// Pré-remplissage des motifs de la table des comptes
function gd_carnet_pre_fill_motifs_comptes() {
	global $wpdb;

	// Les motifs possibles en pré-remplissage dans la gestion des comptes des pilotes
	$listeMotifs = [ 'Mensualité', 'Crédit d\'heures', 'Remboursement de frais' ];

	foreach ($listeMotifs as $un_motif) {
		$select_motif = $wpdb->get_results('SELECT id, motif FROM ' . $wpdb->prefix .'gd_table_motifs_comptes WHERE motif="' . $un_motif . '"');	// Variable déjà sécurisée => pas besoin de prepare
		if ($select_motif == null) {
			$insert_ligne = 'INSERT INTO ' . $wpdb->prefix .'gd_table_motifs_comptes SET motif="' . $un_motif . '"';
			dbDelta($insert_ligne);
			}
		}
}

// Le hook de désinstalation du plugin
register_uninstall_hook(__FILE__, 'gd_carnet_uninstall');

// Fonction de désinstalation (suppression des tables)
function gd_carnet_uninstall () {
// drop des tables
// drop des tables
global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gd_table_vols" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gd_table_ulm" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gd_table_pilote" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gd_table_oaci" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gd_table_pilote_comptes" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gd_table_pilote_ulm_lache" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gd_table_motifs_comptes" );
}

// appelle la fonction gd_carnet_create_table() lors de l'activation du plugin
register_activation_hook(__FILE__, 'gd_carnet_create_table');


// Affichage des détails d'un vol
function gd_carnet_display_un_vol ($numvol, $type_carnet) {	// type_carnet : 0 => pilote, 1 => ulm
	global $wpdb;
	global $volMecanoFlag;
	$current_user = wp_get_current_user();
	
	if (!is_numeric($numvol))	// numvol doit être numérique !
		return;
	if (($type_carnet != 0) && ($type_carnet != 1))	// Forcément 0 ou 1 !
		$type_carnet = 1;
	
	$select_num_pilote_query = $wpdb->prepare('SELECT id, niveau_admin FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
	$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
	
	$le_vol_query = 'SELECT ' . $wpdb->prefix . 'gd_table_vols.id, ' . $wpdb->prefix . 'gd_table_vols.flags, ' . $wpdb->prefix . 'gd_table_vols.date_vol, ' . $wpdb->prefix . 'gd_table_vols.heure_depart, ' . $wpdb->prefix . 'gd_table_vols.heure_arrivee, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_arrivee-' . $wpdb->prefix . 'gd_table_vols.horametre_depart), "%Hh%imn") AS duree, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_depart), "%H,%i") AS hora_start, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_arrivee), "%H,%i") AS hora_end, ' . $wpdb->prefix . 'gd_table_vols.terrain_depart_oaci, ' . $wpdb->prefix . 'gd_table_vols.terrain_arrivee_oaci, ' . $wpdb->prefix . 'gd_table_vols.carburant_depart, ' . $wpdb->prefix . 'gd_table_vols.carburant_arrivee, ' . $wpdb->prefix . 'gd_table_vols.carburant_ajoute, ' . $wpdb->prefix . 'gd_table_vols.plein_complet, ' . $wpdb->prefix . 'gd_table_vols.remarques, ' . $wpdb->prefix . 'gd_table_vols.notes_pilote, ' . $wpdb->prefix . 'gd_table_pilote.nom_pilote, ' . $wpdb->prefix . 'gd_table_ulm.modele, ' . $wpdb->prefix . 'gd_table_ulm.immatriculation FROM ' . $wpdb->prefix . 'gd_table_vols, ' . $wpdb->prefix . 'gd_table_pilote, ' . $wpdb->prefix . 'gd_table_ulm WHERE ' . $wpdb->prefix . 'gd_table_pilote.id=' . $wpdb->prefix . 'gd_table_vols.pilote AND ' . $wpdb->prefix . 'gd_table_ulm.id=' . $wpdb->prefix . 'gd_table_vols.ulm AND ' . $wpdb->prepare( '' . $wpdb->prefix . 'gd_table_vols.id=%d', $numvol);
	$le_vol = $wpdb->get_results($le_vol_query);
	?>
	<h1>D&eacute;tails d'un vol</h1>
	<table border="1">
		<tbody>
			<tr><td>Date du vol&nbsp;: </td><td align="center"><?php echo $le_vol[0]->date_vol; ?></td></tr>
			<tr><td>Heure de d&eacute;part&nbsp;: </td><td align="center"><?php echo $le_vol[0]->heure_depart; ?></td></tr>
			<tr><td>Heure d'arriv&eacute;e&nbsp;: </td><td align="center"><?php echo $le_vol[0]->heure_arrivee; ?></td></tr>
			<tr><td>Pilote&nbsp;: </td><td align="center"><?php echo $le_vol[0]->nom_pilote; ?></td></tr>
<?php
	if (($le_vol[0]->flags & $volMecanoFlag) != 0)
		echo '<tr><td bgcolor="yellow">Vol m&eacute;cano&nbsp;:</td><td align="center" bgcolor="yellow">oui</td></tr>';
?>
			<tr><td>ULM&nbsp;: </td><td align="center"><?php echo $le_vol[0]->modele . ' ' . $le_vol[0]->immatriculation; ?></td></tr>
			<tr><td>Horam&egrave;tre au d&eacute;part&nbsp;: </td><td align="center"><?php echo $le_vol[0]->hora_start; ?></td></tr>
			<tr><td>Horam&egrave;tre &agrave; la fin&nbsp;: </td><td align="center"><?php echo $le_vol[0]->hora_end; ?></td></tr>
			<tr><td>Dur&eacute;e du vol&nbsp;: </td><td align="center"><?php echo $le_vol[0]->duree; ?></td></tr>
			<tr><td>Terrain de d&eacute;part&nbsp;: </td><td align="center"><?php echo $le_vol[0]->terrain_depart_oaci; ?></td></tr>
			<tr><td>Terrain d'arriv&eacute;e&nbsp;: </td><td align="center"><?php echo $le_vol[0]->terrain_arrivee_oaci; ?></td></tr>
			<tr><td>Carburant au d&eacute;part&nbsp;: </td><td align="center"><?php echo $le_vol[0]->carburant_depart; ?> litres</td></tr>
			<tr><td>Carburant &agrave; l'arriv&eacute;e&nbsp;: </td><td align="center"><?php echo $le_vol[0]->carburant_arrivee; ?> litres</td></tr>
<?php
			if ($le_vol[0]->carburant_ajoute != 0) {
				if (!strcmp ($le_vol[0]->plein_complet, 'non'))
					echo '<tr><td>Carburant ajout&eacute;&nbsp;: </td><td align="center">' . $le_vol[0]->carburant_ajoute . ' litres</td></tr>';
				else if (!strcmp ($le_vol[0]->plein_complet, 'avant'))
					echo '<tr><td>Carburant ajout&eacute;&nbsp;: </td><td align="center">' . $le_vol[0]->carburant_ajoute . ' litres (plein avant)</td></tr>';
				else
					echo '<tr><td>Carburant ajout&eacute;&nbsp;: </td><td align="center">' . $le_vol[0]->carburant_ajoute . ' litres (plein apr&egrave;s)</td></tr>';
					
			}
?>
			<tr><td>Remarques&nbsp;: </td><td align="left"><?php echo nl2br($le_vol[0]->remarques); ?></td></tr>
			<tr><td>Notes pilote&nbsp;: </td><td align="left"><?php echo nl2br($le_vol[0]->notes_pilote); ?></td></tr>
			</tr>
		</tbody>
    </table>
	<?php
	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]";
	$tab_link = explode ('/', $_SERVER['REQUEST_URI']);
	$sz = sizeof ($tab_link);
	$resu = '';
	for ($i = 0; $i < $sz -1; $i++) {
		$resu .= $tab_link[$i] . '/';
		}
	echo '<a href="' . $actual_link . $resu . '">Retour &agrave; la liste</a>';
}

// Appel de l'affichage du carnet de vols en mode carnet d'un ULM
function gd_carnet_display_carnet_ulm($atts = array(), $content = null, $tag = '') {
	$atts = array_change_key_case((array) $atts, CASE_LOWER );
	$numUlm = esc_html($atts['ulm']);
	gd_carnet_display_carnet(1, $numUlm);
}

// Appel de l'affichage du carnet de vols en mode carnet du pilote
function gd_carnet_display_carnet_pilote() {
	gd_carnet_display_carnet(0, 0);
}

// Avant le template (spécial pour quand il faut envoyer des headers (téléchargements))
function before_template () {
	global $wpdb;
	
	if (isset ($_GET['csv'])) {
		gd_generer_CSV ($_GET['type_aff'], (isset($_GET['ulm'])) ? $_GET['ulm'] : 0);	// Cette fonction nettoie elle-même les entrées
		exit;
		}
	if (isset($_GET['fichier_note'])) {
		$numFichier = sanitize_text_field($_GET['fichier_note']);
		$le_fichier_query = $wpdb->prepare('SELECT id, fichier FROM ' . $wpdb->prefix . 'gd_table_fichiers WHERE id=%d', $numFichier);
		$le_fichier  = $wpdb->get_results($le_fichier_query);
		$fileNewName = $le_fichier[0]->id;
		$upload_dir   = wp_upload_dir(null, false);
		$monRepertoire = $upload_dir['basedir'] . '/carnetdevols/fichiers';
		$monFichier = $monRepertoire . '/' . $fileNewName;
		
		$fileContent = file_get_contents($monFichier);
		
		// Mettre en mémoire tampon la sortie
		ob_start();

		// Générer le contenu du fichier
		echo $fileContent;

		// Récupérer le contenu de la mémoire tampon et vider la mémoire tampon
		$fileContentBuffer = ob_get_clean();

		// Envoyer le fichier à télécharger
		header('Content-Type: application/octet-stream; charset=utf-8');
		header('Content-Disposition: attachment; filename="' . $le_fichier[0]->fichier . '"');
		echo $fileContentBuffer;
		exit;
		}
	if (isset ($_GET['facture'])) {
		$numEntretien = sanitize_text_field($_GET['facture']);
		$la_facture_query = $wpdb->prepare('SELECT id, facture FROM ' . $wpdb->prefix . 'gd_table_entretien WHERE id=%d', $numEntretien);
		$la_facture  = $wpdb->get_results($la_facture_query);
		$fileNewName = $la_facture[0]->id;
		$upload_dir   = wp_upload_dir(null, false);
		$monRepertoire = $upload_dir['basedir'] . '/carnetdevols';
		$monFichier = $monRepertoire . '/' . $fileNewName;
		
		$fileContent = file_get_contents($monFichier);
		
		// Mettre en mémoire tampon la sortie
		ob_start();

		// Générer le contenu du fichier
		echo $fileContent;

		// Récupérer le contenu de la mémoire tampon et vider la mémoire tampon
		$fileContentBuffer = ob_get_clean();

		// Envoyer le fichier à télécharger
		header('Content-Type: application/octet-stream; charset=utf-8');
		header('Content-Disposition: attachment; filename="' . $la_facture[0]->facture . '"');
		echo $fileContentBuffer;
		exit;
		}
	if (isset ($_GET['flipflopActifs'])) {
		if (!strcmp ($_GET['flipflopActifs'], 'afficheInactifs')) {
			setcookie('flipflopActifs', 'oui', time() + 600);
			}
		else {
			setcookie('flipflopActifs', 'non', time() + 600);
			}
		}
	else {
		if (isset ($_COOKIE['flipflopActifs'])) {
			if (!strcmp ($_COOKIE['flipflopActifs'], 'oui')) {
				setcookie('flipflopActifs', 'oui', time() + 600);
				}
			}
		}
}

// Gestion des soldes des pilotes
function gd_carnet_gestion_liste_soldes_pilote () {
	gd_carnet_display_gestion_liste_soldes_pilote (1);
}

// Liste des pilotes et de leurs soldes
function gd_carnet_display_liste_soldes_pilote () {
	gd_carnet_display_gestion_liste_soldes_pilote (0);
}
	
// Gestion ou liste des pilotes et de leurs soldes
function gd_carnet_display_gestion_liste_soldes_pilote () {
	global $wpdb;
	global $niveauTresorier;
	global $niveauListAll;
	
	$current_user = wp_get_current_user();
	$select_num_pilote_query = $wpdb->prepare('SELECT id, niveau_admin FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
	$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
	if ($select_num_pilote == null) {
		echo '<center><h2><font color="red">Veuillez vous identifier</font></h2></center>';
		return;
		}

	if (($select_num_pilote[0]->niveau_admin & ($niveauListAll + $niveauTresorier)) == 0) {
		gd_carnet_display_compte_pilote(null);
		return;
		}
	$afficheInactifs = false;
	if (isset ($_GET['flipflopActifs'])) {
		if (!strcmp ($_GET['flipflopActifs'], 'afficheInactifs')) {
			$afficheInactifs = true;
			}
		}
	else {
		if (isset ($_COOKIE['flipflopActifs'])) {
			if (!strcmp ($_COOKIE['flipflopActifs'], 'oui')) {
				$afficheInactifs = true;
				}
			}
		}
	// Niveau trésorier pour saisir une écriture
	if (($select_num_pilote[0]->niveau_admin & $niveauTresorier) != 0) {
		echo "<H1>Acc&egrave;s Tr&eacute;sorier</H1>\n";
		echo '<form method="get" action="" id="afficheInactifs">';
		if ($afficheInactifs) {
			echo '<input type="hidden" name="flipflopActifs" value="masqueInactifs" id="masqueInactifs" />';
			echo '<input type="submit" value="Masquer les comptes inactifs" style="background:green"/>';
			}
		else {
			echo '<input type="hidden" name="flipflopActifs" value="afficheInactifs" id="afficheInactifs" />';
			echo '<input type="submit" value="Afficher les comptes inactifs" style="background:orange"/>';
			}
		echo '</form>';
		if (isset ($_POST['motif_operation'])) {
			$piloteOp = sanitize_text_field($_POST['pilote_operation']);
			$dateOp = sanitize_text_field($_POST['date_operation']);
			$motifOp = sanitize_textarea_field($_POST['motif_operation']);
			$creditOp = sanitize_text_field($_POST['credit_operation']);
			$debitOp = sanitize_text_field($_POST['debit_operation']);
			if ($creditOp == '')
				$creditOp = 0;
			if ($debitOp == '')
				$debitOp = 0;
			$wpdb->insert(
				$wpdb->prefix . 'gd_table_pilote_comptes',
				array(
					'id' => NULL,
					'pilote' => $piloteOp,
					'motif' => $motifOp,
					'auteur' => $select_num_pilote[0]->id,
					'credit' => $creditOp,
					'debit' => $debitOp,
					'date' => $dateOp
					)
				);
			}
		if (isset ($_GET['pilote'])) {
			$nomPilote = gd_carnet_display_compte_pilote(sanitize_text_field($_GET['pilote']));
			$numPilote = $_GET['pilote'];
			if (!is_numeric($numPilote)) {
				echo '<hr /><h1>ERREUR DE SAISIE</h1></hr>';
				return;
				}
			if (($select_num_pilote[0]->niveau_admin & $niveauTresorier) != 0) {
				echo '<h2>Ajouter une op&eacute;ration &agrave; ' . $nomPilote . '</h2>';
				
				echo "\n<script type='text/javascript'>\n";
				echo "function onMotifChange (motifSelect) {\n";
				echo 'document.getElementById("motif_operation").value=motifSelect.value' . "\n";
				echo "}\n";
				echo "</script>\n";
				
				echo '<form method="post" action="" id="formFrais">';
				echo '<input type="hidden" id="pilote_operation" name="pilote_operation" value="' . $numPilote . '" /></td>';
				echo '<table border="1"><thead><tr><th>Date (*)</th><th>Motif (*)</th><th>Cr&eacute;dit</th><th>D&eacute;bit</th><th></th></thead><tbody>';
				echo '<td><input type="date" id="date_operation" name="date_operation" required /></td>';
				echo '<td align="center"><select id="motif" name="motif" onchange="onMotifChange(this)">';
				echo '<option value="">-- Choisissez un motif --</option>';
				$liste_motifs = $wpdb->get_results('SELECT motif FROM ' . $wpdb->prefix . 'gd_table_motifs_comptes WHERE actif=true ORDER BY motif ASC');	// Pas de variable, pas besoin de prepare
				foreach ($liste_motifs as $un_motif)
					echo '<option value="' . $un_motif->motif . '">' . $un_motif->motif . '</option>';
				echo '</select>';
				echo '<br />Ou saisissez un motif<br />';
				echo '<textarea id="motif_operation" name="motif_operation" rows=5 cols=30 maxlength="200" required></textarea></td>';
				echo '<td><input type="number" step="0.01" id="credit_operation" name="credit_operation" /></td>';
				echo '<td><input type="number" step="0.01" id="debit_operation" name="debit_operation" /></td>';
				echo '<td><input type="submit" id="submitFrais"/><input type="button" id="attenteFrais" value="Envoi en cours..." style="display:none;background:orange"/></td>';
				echo '</tbody></table>';
				echo '</form>';
				echo "\n<script>\n";
				echo "document.getElementById('formFrais').addEventListener('submit', function() {\n";
				echo "document.getElementById('submitFrais').disabled = true;\n";
				echo "document.getElementById('submitFrais').style.display = 'none';\n";
				echo "document.getElementById('attenteFrais').style.display = 'block';\n";
				echo "});\n";
				echo "</script>\n";
				}
			}
			echo '<h1>Les soldes des pilotes</h1>';
		}
	else
		echo '<h1>Soldes des pilotes</h1>';
	$listePilotes = get_users();
	foreach ($listePilotes as $unPilote) {
//		echo esc_html($unPilote->user_login) . ' : ' . esc_html($unPilote->display_name) . "<br />\n";
		$select_un_pilote_query = $wpdb->prepare('SELECT id FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $unPilote->user_login);
		$select_un_pilote = $wpdb->get_results($select_un_pilote_query);
		if ($select_un_pilote == null) { // Si on n'a pas encore un carnet de vols pour cet utilisateur
				$table_name = $wpdb->prefix . 'gd_table_pilote';
				$wpdb->insert(
					$table_name,
					array(
						'id' => NULL,
						'user_login' => $unPilote->user_login,
						'nom_pilote' => $unPilote->display_name,
						'lache' => 0,
						'remarques' => "Creation automatique"
						)
					);
				$pilote_id = $wpdb->insert_id;
			}
		}
	// Pas de paramètre, pas besoin de prepare
	$liste_pilotes = $wpdb->get_results( 'SELECT id, user_login, nom_pilote, brevet, lache, date_lache, emport, date_emport, remarques, actif FROM ' . $wpdb->prefix . 'gd_table_pilote ORDER BY nom_pilote ASC');
	echo '<table border="1"><tbody><tr><td>Compte</td><td>Nom pilote</td><td>Remarques</td><td>Solde</td></tr>';
	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'] . '?page=' . 'page';
	foreach ($liste_pilotes as $un_pilote) {
		if (!$afficheInactifs || ($select_num_pilote[0]->niveau_admin & $niveauTresorier) == 0) {
			if ($un_pilote->actif != true)	// Préparation visibilité des inactifs
				continue;
			}
		if ($un_pilote->actif != true) {
			echo '<tr bgcolor="#FB9D62">';
			$remarques = $un_pilote->remarques . ' (inactif)';
			}
		else {
			echo '<tr>';
			$remarques = $un_pilote->remarques;
			}
		echo '<td><a href=?pilote=' . $un_pilote->id . '>' . $un_pilote->user_login . '</a></td><td>' . $un_pilote->nom_pilote . '</td><td>'. $remarques . '</td>';
		$pilote_solde_query = $wpdb->prepare('SELECT SUM(credit) AS entrees, SUM(debit) AS sorties FROM ' . $wpdb->prefix . 'gd_table_pilote_comptes WHERE pilote=%d', $un_pilote->id);
		$pilote_solde = $wpdb->get_results($pilote_solde_query);
		if ($pilote_solde == null)
			$le_solde = 0;
		else {
			if ($pilote_solde[0]->entrees == null)
				$entrees = 0;
			else
				$entrees = $pilote_solde[0]->entrees;

			if ($pilote_solde[0]->sorties == null)
				$sorties = 0;
			else
				$sorties = $pilote_solde[0]->sorties;
			
			$le_solde = $entrees - $sorties;
			}
		if ($le_solde < 0)
			echo '<td align=center bgcolor=#FF9999>' . $le_solde . '</td></tr>';
		else
			echo '<td align=center>' . $le_solde . '</td></tr>';
		}
		echo '</tbody></table>';
}

// Affichage du livre de compte du pilote en cours ou de celui passé en paramètre
function gd_carnet_display_compte_pilote($num_pilote) {
    // Affiche le contenu de la sous-page
	global $wpdb;
	global $nbMaxAff;

	if ($num_pilote == null) {
		$current_user = wp_get_current_user();
		$ulm_lache_query = $wpdb->prepare('SELECT id FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
		$select_num_pilote = $wpdb->get_results($ulm_lache_query);
		if ($select_num_pilote == null) { // Si on n'a pas encore affiché un carnet de vols pour cet utilisateur
			$table_name = $wpdb->prefix . 'gd_table_pilote';
			$wpdb->insert(
				$table_name,
				array(
					'id' => NULL,
					'user_login' => $current_user->user_login,
					'nom_pilote' => $current_user->display_name,
					'lache' => 0,
					'remarques' => "Creation automatique"
					)
				);
			$pilote_id = $wpdb->insert_id;
			}
		else
			$pilote_id = $select_num_pilote[0]->id;
		echo '<h1>Mon livre de comptes</h1>';
		}
	else {
		$pilote_id = $num_pilote;
		if (!is_numeric($pilote_id)) {
			echo '<hr /><h1>ERREUR DE SAISIE</h1></hr>';
			return;
			}
		$ulm_lache_query = $wpdb->prepare('SELECT nom_pilote, actif FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE id=%d', $num_pilote);
		$get_nom_pilote = $wpdb->get_results($ulm_lache_query);
		if ($get_nom_pilote[0]->actif)
			echo '<h1>Livre de comptes de ' . $get_nom_pilote[0]->nom_pilote . '</h1>';
		else
			echo '<h1>Livre de comptes de ' . $get_nom_pilote[0]->nom_pilote . ' (INACTIF)</h1>';
		}
	echo '<table border="1">';
	$pilote_solde_query = $wpdb->prepare('SELECT SUM(credit) AS entrees, SUM(debit) AS sorties FROM ' . $wpdb->prefix . 'gd_table_pilote_comptes WHERE pilote=%d', $pilote_id);
	$pilote_solde = $wpdb->get_results($pilote_solde_query);
	if ($pilote_solde == null)
		$le_solde = 0;
	else {
		if ($pilote_solde[0]->entrees == null)
			$entrees = 0;
		else
			$entrees = $pilote_solde[0]->entrees;

		if ($pilote_solde[0]->sorties == null)
			$sorties = 0;
		else
			$sorties = $pilote_solde[0]->sorties;
		
		$le_solde = $entrees - $sorties;
		}
	echo '<tr><td colspan=2 align=center>Solde</td>';
	if ($le_solde < 0)
		echo '<td colspan=2 align=center bgcolor=#FF9999>' . $le_solde . '</td></tr>';
	else
		echo '<td colspan=2 align=center>' . $le_solde . '</td></tr>';
	echo '<tr><td>Date</td><td>Motif</td><td>Cr&eacute;dit</td><td>D&eacute;bit</td></tr>';
	$mes_comptes_query = 'SELECT motif, auteur, credit, debit, DATE_FORMAT(date, "%d/%m/%Y") AS le_jour FROM ' . $wpdb->prefix . 'gd_table_pilote_comptes ';
	$mes_comptes_query .= $wpdb->prepare('WHERE pilote=%d ORDER BY date DESC, id DESC LIMIT %d', $pilote_id, $nbMaxAff);
	$mes_comptes = $wpdb->get_results($mes_comptes_query);
	foreach ($mes_comptes as $une_ligne) {
		echo '<tr><td align="center">' . $une_ligne->le_jour . '</td><td>&nbsp;' . $une_ligne->motif . '</td><td align="right">' . (($une_ligne->credit=="0.0")?'':$une_ligne->credit) . '</td><td align="right">' . (($une_ligne->debit=="0.0")?'':$une_ligne->debit) . '</td></tr>';
		}
	echo '</table>';
	if ($num_pilote != null)
		return $get_nom_pilote[0]->nom_pilote;
}

// Génération du carnet de vols au format CSV après nettoyage des entrées
function gd_generer_CSV ($type_aff, $num_ulm) {
	global $wpdb;
	if ($type_aff == 0) { // 0 => pilote
			$current_user = wp_get_current_user();
			$pilote_solde_query = $wpdb->prepare('SELECT id FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
			$select_num_pilote = $wpdb->get_results($pilote_solde_query);
			if ($select_num_pilote == null) { // Si on n'a pas encore affiché un carnet de vols pour cet utilisateur
				$table_name = $wpdb->prefix . 'gd_table_pilote';
				$wpdb->insert(
					$table_name,
					array(
						'id' => NULL,
						'user_login' => $current_user->user_login,
						'nom_pilote' => $current_user->display_name,
						'lache' => 0,
						'remarques' => "Creation automatique"
						)
					);
				$pilote_id = $wpdb->insert_id;
				}
			else
				$pilote_id = $select_num_pilote[0]->id;

			// On récupère tous les vols
			// $pilote_id provient d'un SELECT => il est déjà "propre", pas besoin de $wpdb->prepare
			$vols = $wpdb->get_results( 'SELECT ' . $wpdb->prefix . 'gd_table_vols.id, ' . $wpdb->prefix . 'gd_table_vols.date_vol, ' . $wpdb->prefix . 'gd_table_vols.heure_depart, ' . $wpdb->prefix . 'gd_table_vols.heure_arrivee, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_arrivee-' . $wpdb->prefix . 'gd_table_vols.horametre_depart), "%Hh%imn") AS duree, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_depart), "%H,%i") AS hora_start, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_arrivee), "%H,%i") AS hora_end, ' . $wpdb->prefix . 'gd_table_vols.terrain_depart_oaci, ' . $wpdb->prefix . 'gd_table_vols.terrain_arrivee_oaci, ' . $wpdb->prefix . 'gd_table_vols.carburant_depart, ' . $wpdb->prefix . 'gd_table_vols.carburant_arrivee, ' . $wpdb->prefix . 'gd_table_vols.carburant_ajoute, ' . $wpdb->prefix . 'gd_table_vols.plein_complet, ' . $wpdb->prefix . 'gd_table_vols.remarques, ' . $wpdb->prefix . 'gd_table_vols.notes_pilote, ' . $wpdb->prefix . 'gd_table_pilote.nom_pilote, ' . $wpdb->prefix . 'gd_table_ulm.modele, ' . $wpdb->prefix . 'gd_table_ulm.immatriculation FROM ' . $wpdb->prefix . 'gd_table_vols, ' . $wpdb->prefix . 'gd_table_pilote, ' . $wpdb->prefix . 'gd_table_ulm WHERE ' . $wpdb->prefix . 'gd_table_vols.ulm=' . $wpdb->prefix . 'gd_table_ulm.id AND ' . $wpdb->prefix . 'gd_table_vols.pilote=' . $pilote_id . ' AND ' . $wpdb->prefix . 'gd_table_pilote.id=' . $pilote_id . ' ORDER BY ' . $wpdb->prefix . 'gd_table_vols.id DESC');
			}
		else if ($type_aff == 1) { // 1 => ulm
			$cleaned_num_ulm = $wpdb->prepare('%d', $num_ulm);
			$vols = $wpdb->get_results( "SELECT " . $wpdb->prefix . "gd_table_vols.id, " . $wpdb->prefix . "gd_table_vols.date_vol, " . $wpdb->prefix . "gd_table_vols.heure_depart, " . $wpdb->prefix . "gd_table_vols.heure_arrivee, TIME_FORMAT(SEC_TO_TIME(" . $wpdb->prefix . "gd_table_vols.horametre_arrivee-" . $wpdb->prefix . "gd_table_vols.horametre_depart), \"%Hh%imn\") AS duree, TIME_FORMAT(SEC_TO_TIME(" . $wpdb->prefix . "gd_table_vols.horametre_depart), \"%H,%i\") AS hora_start, TIME_FORMAT(SEC_TO_TIME(" . $wpdb->prefix . "gd_table_vols.horametre_arrivee), \"%H,%i\") AS hora_end, " . $wpdb->prefix . "gd_table_vols.terrain_depart_oaci, " . $wpdb->prefix . "gd_table_vols.terrain_arrivee_oaci, " . $wpdb->prefix . "gd_table_vols.carburant_depart, " . $wpdb->prefix . "gd_table_vols.carburant_arrivee, " . $wpdb->prefix . "gd_table_vols.carburant_ajoute, " . $wpdb->prefix . "gd_table_vols.plein_complet, " . $wpdb->prefix . "gd_table_vols.remarques, " . $wpdb->prefix . "gd_table_vols.notes_pilote, " . $wpdb->prefix . "gd_table_pilote.nom_pilote, " . $wpdb->prefix . "gd_table_ulm.modele, " . $wpdb->prefix . "gd_table_ulm.immatriculation FROM " . $wpdb->prefix . "gd_table_vols, " . $wpdb->prefix . "gd_table_pilote, " . $wpdb->prefix . "gd_table_ulm WHERE " . $wpdb->prefix . "gd_table_vols.ulm=$cleaned_num_ulm AND " . $wpdb->prefix . "gd_table_ulm.id=" . $wpdb->prefix . "gd_table_vols.ulm AND " . $wpdb->prefix . "gd_table_pilote.id=" . $wpdb->prefix . "gd_table_vols.pilote ORDER BY " . $wpdb->prefix . "gd_table_vols.id DESC" );
			}
		else	// type_aff n'est ni 0 ni 1 => entrée invalide !
			return;

	// Première ligne du CSV (étiquettes)
	$fileContent8 = 'Date du vol;Heure de départ;Heure d\'arrivée;Pilote;ULM;Horamètre au départ;Horamètre à la fin;Durée du vol;Terrain de départ;Terrain d\'arrivée;Carburant au départ;Carburant à l\'arrivée;Carburant ajouté;Plein complet;Remarques;Notes pilote' . "\n";
	$fileContent = mb_convert_encoding ($fileContent8, 'ISO-8859-1', 'UTF-8');
	foreach ($vols as $un_vol) {
		$fileContent .= mb_convert_encoding ($un_vol->date_vol . ';' . $un_vol->heure_depart . ';' . $un_vol->heure_arrivee . ';' . $un_vol->nom_pilote . ';' . $un_vol->modele . ' ' . $un_vol->immatriculation . ';' . $un_vol->hora_start . ';' . $un_vol->hora_end . ';' . $un_vol->duree . ';' . $un_vol->terrain_depart_oaci . ';' . $un_vol->terrain_arrivee_oaci . ';' . $un_vol->carburant_depart . ';' . $un_vol->carburant_arrivee . ';' . $un_vol->carburant_ajoute . ';' . $un_vol->plein_complet . ';' . $un_vol->remarques . ';' . $un_vol->notes_pilote . "\n", 'ISO-8859-1', 'UTF-8');
		}

    // Mettre en mémoire tampon la sortie
    ob_start();

    // Générer le contenu du fichier
    echo $fileContent;

    // Récupérer le contenu de la mémoire tampon et vider la mémoire tampon
    $fileContentBuffer = ob_get_clean();

    // Envoyer le fichier à télécharger
    header('Content-Type: application/octet-stream; charset=utf-8');
    header('Content-Disposition: attachment; filename="CarnetDeVols.csv"');
    echo $fileContentBuffer;
	exit;
}


// Affichage de la liste des vols enregistrés
function gd_carnet_display_carnet($type_aff, $num_ulm) {
	global $nbMaxAff;
	global $volMecanoFlag;

	if (isset ($_GET['vol'])) {
		$type_carnet = 1;
		if (isset ($_GET['type_carnet']))
			$type_carnet = $_GET['type_carnet'];
		if (($type_carnet != 0) && ($type_carnet != 1))
			$type_carnet = 1;
		gd_carnet_display_un_vol ($_GET['vol'], $type_carnet);	// Cette fonction nettoie elle-même ses entrées
		return;
		}
/*
	else if (isset ($_GET['csv'])) {
		gd_generer_CSV ($type_aff, $num_ulm);	// Cette fonction nettoie elle-même les entrées
		return;
		}
*/
    global $wpdb;
    ?>
    <div class="wrap">
	<?php
		if ($type_aff == 0) { // 0 => pilote
			$current_user = wp_get_current_user();
			$select_num_pilote_query = $wpdb->prepare('SELECT id FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
			$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
			if ($select_num_pilote == null) { // Si on n'a pas encore affiché un carnet de vols pour cet utilisateur
				$table_name = $wpdb->prefix . 'gd_table_pilote';
				$wpdb->insert(
					$table_name,
					array(
						'id' => NULL,
						'user_login' => $current_user->user_login,
						'nom_pilote' => $current_user->display_name,
						'lache' => 0,
						'remarques' => "Creation automatique"
						)
					);
				$pilote_id = $wpdb->insert_id;
				}
			else
				$pilote_id = $select_num_pilote[0]->id;

			// On n'affiche que les nbMaxAff derniers vols
			$vols_query = 'SELECT ' . $wpdb->prefix . 'gd_table_vols.id, ' . $wpdb->prefix . 'gd_table_vols.date_vol, ' . $wpdb->prefix . 'gd_table_vols.heure_depart, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_arrivee-' . $wpdb->prefix . 'gd_table_vols.horametre_depart), "%Hh%imn") AS duree, (' . $wpdb->prefix . 'gd_table_vols.horametre_arrivee-' . $wpdb->prefix . 'gd_table_vols.horametre_depart) AS duree_secondes, ' . $wpdb->prefix . 'gd_table_vols.cout_du_vol, TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix . 'gd_table_vols.horametre_arrivee), "%H,%i") AS hora_end, ' . $wpdb->prefix . 'gd_table_vols.carburant_arrivee, ' . $wpdb->prefix . 'gd_table_vols.terrain_depart_oaci, ' . $wpdb->prefix . 'gd_table_vols.terrain_arrivee_oaci, ' . $wpdb->prefix . 'gd_table_vols.remarques, ' . $wpdb->prefix . 'gd_table_vols.notes_pilote, ' . $wpdb->prefix . 'gd_table_pilote.nom_pilote, ' . $wpdb->prefix . 'gd_table_ulm.tarif_heure, ' . $wpdb->prefix . 'gd_table_ulm.modele, ' . $wpdb->prefix . 'gd_table_ulm.immatriculation FROM ' . $wpdb->prefix . 'gd_table_vols, ' . $wpdb->prefix . 'gd_table_pilote, ' . $wpdb->prefix . 'gd_table_ulm ';
			$vols_query .= $wpdb->prepare('WHERE ' . $wpdb->prefix . 'gd_table_vols.ulm=' . $wpdb->prefix . 'gd_table_ulm.id AND ' . $wpdb->prefix . 'gd_table_vols.pilote=%d AND ' . $wpdb->prefix . 'gd_table_pilote.id=%d ORDER BY ' . $wpdb->prefix . 'gd_table_vols.id DESC LIMIT %d', $pilote_id, $pilote_id, $nbMaxAff);
			$vols = $wpdb->get_results($vols_query);
			echo '<h1>Carnet de vols de ' . $current_user->display_name . '</h1>';
			}
		else if ($type_aff == 1) { // 1 => ulm
			$cleaned_num_ulm = $wpdb->prepare('%d', $num_ulm);
			$vols = $wpdb->get_results( "SELECT " . $wpdb->prefix ."gd_table_vols.id, " . $wpdb->prefix ."gd_table_vols.date_vol, " . $wpdb->prefix ."gd_table_vols.flags, " . $wpdb->prefix ."gd_table_vols.heure_depart, TIME_FORMAT(SEC_TO_TIME(" . $wpdb->prefix ."gd_table_vols.horametre_arrivee-" . $wpdb->prefix ."gd_table_vols.horametre_depart), '%Hh%imn') AS duree, TIME_FORMAT(SEC_TO_TIME(" . $wpdb->prefix ."gd_table_vols.horametre_arrivee), '%H,%i') AS hora_end, " . $wpdb->prefix ."gd_table_vols.carburant_arrivee, " . $wpdb->prefix ."gd_table_vols.remarques, " . $wpdb->prefix ."gd_table_vols.notes_pilote,  " . $wpdb->prefix ."gd_table_pilote.nom_pilote, " . $wpdb->prefix ."gd_table_ulm.modele, " . $wpdb->prefix ."gd_table_ulm.immatriculation, " . $wpdb->prefix ."gd_table_vols.terrain_depart_oaci, " . $wpdb->prefix ."gd_table_vols.terrain_arrivee_oaci FROM " . $wpdb->prefix ."gd_table_vols, " . $wpdb->prefix ."gd_table_pilote, " . $wpdb->prefix ."gd_table_ulm WHERE " . $wpdb->prefix ."gd_table_vols.ulm=$cleaned_num_ulm AND " . $wpdb->prefix ."gd_table_ulm.id=" . $wpdb->prefix ."gd_table_vols.ulm AND " . $wpdb->prefix ."gd_table_pilote.id=" . $wpdb->prefix ."gd_table_vols.pilote ORDER BY " . $wpdb->prefix ."gd_table_vols.id DESC LIMIT $nbMaxAff" );
			if ($vols == null) {
				$leULM = $wpdb->get_results('SELECT modele, immatriculation FROM ' . $wpdb->prefix .'gd_table_ulm WHERE id=' . $cleaned_num_ulm);
				echo '<h1>Carnet de vols du ' . $leULM[0]->modele . ' ' . $leULM[0]->immatriculation . '</h1>';
				}
			else
				echo '<h1>Carnet de vols du ' . $vols[0]->modele . ' ' . $vols[0]->immatriculation . '</h1>';
			}
		$urlCsv = '?csv=oui&type_aff=' . $type_aff;
		if ($type_aff == 1)
			$urlCsv .= '&ulm=' . $num_ulm;
		echo '<a href="' . $urlCsv . '" >T&eacute;l&eacute;charger le carnet de vols</a><br /><br />';
	?>
        <table border="1">
            <thead>
                <tr>
                    <th>Date<br />du vol</th>
					<th>Heure<br />d&eacute;part</th>
                    <th>Dur&eacute;e<br />du vol</th>
	<?php
					if ($type_aff == 0) { // 0 => pilote
						echo '<th>Co&ucirc;t<br />du vol</th>';
						}
					else if ($type_aff == 1) { // 1 => ulm
						echo '<th>Horam&egrave;tre<br />arriv&eacute;e</th>';
						}
	?>
					<th>Carburant<br />arriv&eacute;e</th>
					<th>Terrain<br />d&eacute;part</th>
					<th>Terrain<br />arriv&eacute;e</th>
	<?php
					if ($type_aff == 0) { // 0 => pilote
						echo '<th>ULM</th>';
						echo '<th>Notes pilote</th>';
						}
					else if ($type_aff == 1) { // 1 => ulm
						echo '<th>Pilote</th>';
						echo '<th>Remarques</th>';
						}
	?>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($vols as $un_vol) {
                    ?>
                    <tr>
                        <td align="center"><?php echo '<a href=?vol=' . $un_vol->id . '&type_carnet=' . $type_aff . '>' . $un_vol->date_vol . '</a>'; ?></td>
						<td align="center"><?php echo $un_vol->heure_depart; ?></td>
                        <td align="center"><?php echo $un_vol->duree; ?></td>
	<?php
					if ($type_aff == 0) { // 0 => pilote
						$coutDuVol = $un_vol->cout_du_vol;
						echo '<td align="center">' . number_format((float)$coutDuVol, 2, '&euro;', '') . '</td>';
						}
					else if ($type_aff == 1) { // 1 => ulm
						echo '<td align="center">' . $un_vol->hora_end . '</td>';
						}
	?>
						<td align="center"><?php echo $un_vol->carburant_arrivee; ?></td>
						<td align="center"><?php echo $un_vol->terrain_depart_oaci; ?></td>
						<td align="center"><?php echo $un_vol->terrain_arrivee_oaci; ?></td>
	<?php
					if ($type_aff == 0) { // 0 => pilote
                        echo '<td align="center">' . $un_vol->modele . ' ' . $un_vol->immatriculation . '</td>';
						$texte_libre = $un_vol->notes_pilote;
						}
					else if ($type_aff == 1) { // 1 => ulm
						if (($un_vol->flags & $volMecanoFlag) != 0)
							echo '<td align="center" bgcolor="yellow">' . $un_vol->nom_pilote . '</td>';
						else
							echo '<td align="center">' . $un_vol->nom_pilote . '</td>';
						$texte_libre = $un_vol->remarques;
						}
				if (strlen($texte_libre) > 20) {
					$remarques = substr($texte_libre,0,17);
					echo '<td align="center">' . $remarques . ' <b>(...)</b></td>';
					}
				else
					echo '<td align="center">' . $texte_libre . '</td>';
	?>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Gestion de l'ajout d'un vol dans la base
function gd_carnet_ajoute_vol() {
	global $wpdb;
	global $plein_complet_liste;
	global $plein_complet_liste_texte;
	global $niveauMecano;
	
	$current_user = wp_get_current_user();
	$select_num_pilote_query = $wpdb->prepare('SELECT id, actif, niveau_admin FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
	$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
	if ($select_num_pilote == null) {
		echo '<center><h2><font color="red">Veuillez vous identifier</font></h2></center>';
		return;
		}
	$pilote_id = $select_num_pilote[0]->id;
	
	if ($select_num_pilote[0]->actif == false) {
		echo '<center><h2><font color="red">Compte d&eacute;sactiv&eacute;, contactez votre administrateur</font></h2></center>';
		return;
		}

    // si le formulaire a été soumis, ajoute la transaction dans la base de données
    if (isset($_POST['heure_depart']) && isset($_POST['heure_arrivee']) && isset($_POST['horametre_arrivee'])) {
        global $wpdb;

		// Récupération / nettoyage des entrées
		if (isset($_POST['volmecano']))
			$volmecano = true;
		else
			$volmecano = false;
        $date_vol = sanitize_text_field($_POST['date_vol']);
		$heure_depart = sanitize_text_field($_POST['heure_depart']) . ':00';
		$heure_arrivee = sanitize_text_field($_POST['heure_arrivee']) . ':00';
		$ulm = sanitize_text_field($_POST['ulm']);
        $horametre_depart = floatval(sanitize_text_field(str_replace(',' , '.', $_POST['horametre_depart'])));
		
		$horametre_arrivee = floatval(sanitize_text_field(str_replace(',' , '.', $_POST['horametre_arrivee'])));
		$terrain_depart_oaci = sanitize_text_field($_POST['terrain_depart_oaci']);
		$terrain_arrivee_oaci = sanitize_text_field($_POST['terrain_arrivee_oaci']);
		$carburant_depart = sanitize_text_field($_POST['carburant_depart']);
		$carburant_arrivee = sanitize_text_field($_POST['carburant_arrivee']);
		$carburant_ajoute = sanitize_text_field($_POST['carburant_ajoute']);
		$leplein = sanitize_text_field($_POST['leplein']);
		$remarques = sanitize_textarea_field($_POST['remarques']);
		$notes_pilote = sanitize_textarea_field($_POST['notes_pilote']);
		
		$heures_horametre_depart = (int)$horametre_depart;
		$minutes_horametre_depart = round(($horametre_depart - $heures_horametre_depart) * 100);
		$horadepart = (($heures_horametre_depart * 60) + $minutes_horametre_depart) * 60;

		$heures_horametre_arrivee = (int)$horametre_arrivee;
		$minutes_horametre_arrivee = round(($horametre_arrivee - $heures_horametre_arrivee) * 100);
		$horaarrivee = (($heures_horametre_arrivee * 60) + $minutes_horametre_arrivee) * 60;
		
		$duree_de_vol = ($horaarrivee - $horadepart) / 60;
		
		// Vérifications
		$aff_erreur = false;
		$msg_erreur = 'Erreur dans le formulaire&nbsp;:<br />';
		// Format de date
		$tab_date_vol = explode("-",$date_vol);
		if (!checkdate($tab_date_vol[1], $tab_date_vol[2], $tab_date_vol[0])) {
			$aff_erreur = true;
			$msg_erreur .= 'Date de vol invalide<br />';
			}
		// Ordre des relevés de l'horamètre
		if ($horadepart > $horaarrivee) {
			$aff_erreur = true;
			$msg_erreur .= 'Horam&egrave;tre arriv&eacute;e inf&eacute;rieur &agrave; celui de d&eacute;part<br />';
			}
		// Format heure de départ
		if (preg_match("/^(?:2[0-4]|[01][1-9]|10):([0-5][0-9]):00$/", $heure_depart) != 1) {
			$aff_erreur = true;
			$msg_erreur .= 'Heure de d&eacute;part invalide<br />';
			}
		// Format heure d'arrivée
		if (preg_match("/^(?:2[0-4]|[01][1-9]|10):([0-5][0-9]):00$/", $heure_arrivee) != 1) {
			$aff_erreur = true;
			$msg_erreur .= 'Heure d\'arriv&eacute;e invalide<br />';
			}
		// Ordre des horaires
		$tab_heure_depart = explode (':', $heure_depart);
		$timedepart = strtotime ($heure_depart);
		$timearrivee = strtotime ($heure_arrivee);
		if ($timearrivee <= $timedepart) {
			$aff_erreur = true;
			$msg_erreur .= 'Heure d\'arriv&eacute;e ant&eacute;rieure &agrave; l\'heure de d&eacute;part<br />';
			}
		
		if ($aff_erreur) {
			echo $msg_erreur;
			echo '<hr /><br /><a href="javascript:history.back()">Retour pour corriger</a>';
			exit;
			}
		else {
			$tarif_ulm_query = $wpdb->prepare('SELECT tarif_heure, immatriculation FROM ' . $wpdb->prefix .'gd_table_ulm WHERE id=%d', $ulm);
			$tarif_ulm = $wpdb->get_results($tarif_ulm_query);
			if ($volmecano)
				$coutDuVol = 0;
			else
				$coutDuVol = ($tarif_ulm[0]->tarif_heure / 60) * $duree_de_vol;
			$valeurFlags = 0;
			if ($volmecano)
				$valeurFlags |= $volMecanoFlag;
			$wpdb->insert(
			$wpdb->prefix .'gd_table_vols',
				array(
					'pilote' => $pilote_id,
					'flags' => $valeurFlags,
					'ulm' => $ulm,
					'date_vol' => $date_vol,
					'heure_depart' => $heure_depart,
					'heure_arrivee' => $heure_arrivee,
					'horametre_depart' => $horadepart,
					'horametre_arrivee' => $horaarrivee,
					'minutes_de_vol' => $duree_de_vol,
					'cout_du_vol' => $coutDuVol,
					'terrain_depart_oaci' => $terrain_depart_oaci,
					'terrain_arrivee_oaci' => $terrain_arrivee_oaci,
					'carburant_depart' => $carburant_depart,
					'carburant_arrivee' => $carburant_arrivee,
					'carburant_ajoute' => $carburant_ajoute,
					'plein_complet' => $leplein,
					'remarques' => $remarques,
					'notes_pilote' => $notes_pilote,
					'date_creation' => current_time('mysql', 1),
					'derniere_modification' => current_time('mysql', 1)
					)
				);
			$idvol = $wpdb->insert_id;
			if ($coutDuVol != 0) {
				$wpdb->insert(
				$wpdb->prefix .'gd_table_pilote_comptes',
					array(
						'pilote' => $pilote_id,
						'motif' => 'vol sur ' . $tarif_ulm[0]->immatriculation,
						'auteur' => $pilote_id,
						'debit' => $coutDuVol,
						'id_vol' => $idvol,
						'date' => $date_vol
						)
					);
				}
			echo '<br /><hr /><b>Votre saisie a &eacute;t&eacute; enregistr&eacute;e, merci.</b><hr /><br />';
			}

    }

    // affiche le formulaire d'ajout de vol
	$liste_ulm_lache_actif_query = $wpdb->prepare('SELECT ' . $wpdb->prefix .'gd_table_ulm.id, immatriculation, modele FROM ' . $wpdb->prefix .'gd_table_ulm, ' . $wpdb->prefix .'gd_table_pilote_ulm_lache, ' . $wpdb->prefix .'gd_table_pilote WHERE ' . $wpdb->prefix .'gd_table_ulm.id=' . $wpdb->prefix .'gd_table_pilote_ulm_lache.ulm AND ' . $wpdb->prefix .'gd_table_ulm.actif=true AND ' . $wpdb->prefix .'gd_table_pilote_ulm_lache.pilote=' . $wpdb->prefix .'gd_table_pilote.id AND ' . $wpdb->prefix .'gd_table_pilote.user_login=%s', $current_user->user_login);
	$liste_ulm_lache_actif = $wpdb->get_results($liste_ulm_lache_actif_query);
	$nbULM = 0;
	foreach ($liste_ulm_lache_actif as $un_ulm) {
		// un_ulm->id provient du query : pas besoin de prepare
		$dernier_vol = $wpdb->get_results( 'SELECT TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix .'gd_table_vols.horametre_arrivee), "%H.%i") AS hora_end, carburant_arrivee, terrain_arrivee_oaci FROM ' . $wpdb->prefix .'gd_table_vols WHERE ulm=' . $un_ulm->id . ' ORDER BY horametre_arrivee DESC LIMIT 1');
		$nbULM++;
		$tab_ulm_id[] = $un_ulm->id;
		if ($dernier_vol == null) {
			$tab_hora_end[] = 0;
			$tab_terrain_arrivee_oaci[] = '';
			$tab_carburant_arrivee[] = 0;
			}
		else {
			$tab_hora_end[] = $dernier_vol[0]->hora_end;
			$tab_terrain_arrivee_oaci[] = $dernier_vol[0]->terrain_arrivee_oaci;
			$tab_carburant_arrivee[] = $dernier_vol[0]->carburant_arrivee;
			}
		}
		if ($nbULM == 0) {
			$tab_hora_end[] = 0;
			$tab_terrain_arrivee_oaci[] = '';
			$tab_carburant_arrivee[] = 0;
			}
		
		echo "<script type='text/javascript'>\n";
		echo 'let tab_ulm_id = [ ' . $tab_ulm_id[0];
		for ($i = 1; $i < $nbULM; $i++)
			echo ', ' . $tab_ulm_id[$i];
		echo " ];\n";
		echo 'let tab_hora_end = [ ' . $tab_hora_end[0];
		for ($i = 1; $i < $nbULM; $i++)
			echo ', ' . $tab_hora_end[$i];
		echo " ];\n";
		echo 'let tab_terrain_arrivee_oaci = [ "' . $tab_terrain_arrivee_oaci[0];
		for ($i = 1; $i < $nbULM; $i++)
			echo '", "' . $tab_terrain_arrivee_oaci[$i];
		echo '"' . " ];\n";
		echo 'let tab_carburant_arrivee = [ ' . $tab_carburant_arrivee[0];
		for ($i = 1; $i < $nbULM; $i++)
			echo ', ' . $tab_carburant_arrivee[$i];
		echo " ];\n";
		echo "function onUlmChange (ulmSelect) {\n";
		echo 'for (numULM = 0; numULM < ' . $nbULM . '; numULM++) {' . "\n";
		echo 'if (tab_ulm_id[numULM] == ulmSelect.value) {' . "\n";
		echo 'document.getElementById("horametre_depart").value=tab_hora_end[numULM]' . "\n";
		echo 'document.getElementById("terrain_depart_oaci").value=tab_terrain_arrivee_oaci[numULM]' . "\n";
		echo 'document.getElementById("carburant_depart").value=tab_carburant_arrivee[numULM]' . "\n";
		echo "}\n";
		echo "}\n";
		echo "}\n";
		echo "</script>\n";
    ?>
    <form method="post" action="" id="formUnVol">
		<table border="0">
			<tbody>
				<tr><td><?php _e('Pilote&nbsp;');?>: </td><td align="left"><?php echo $current_user->display_name; ?></td></tr>
<?php
	if (($select_num_pilote[0]->niveau_admin & $niveauMecano) != 0)
		echo '<tr><td>Vol m&eacute;cano&nbsp;? </td><td align="left"><input type="checkbox" id="volmecano" name="volmecano" /></td></tr>';
?>
				<tr><td><?php _e('Date du vol&nbsp;');?>: (*)</td><td align="left"><input type="date" id="date_vol" name="date_vol" value="<?php echo date('Y-m-d'); ?>" required /></td></tr>
				<tr><td><?php _e('Heure de d&eacute;part&nbsp;');?>: (*)</td><td align="left"><input type="time" id="heure_depart" name="heure_depart" required /></td></tr>
				<tr><td><?php _e('Heure d\'arriv&eacute;e&nbsp;');?>: (*)</td><td align="left"><input type="time" id="heure_arrivee" name="heure_arrivee" required /></td></tr>
				<tr><td><?php _e('ULM&nbsp;');?>: (*)</td><td align="left">
				<select id="ulm" name="ulm" onchange="onUlmChange(this)">
<?php
	foreach ($liste_ulm_lache_actif as $un_ulm) {
		echo '<option value=' . $un_ulm->id . '>' . $un_ulm->modele . ' ' . $un_ulm->immatriculation . '</option>';
		}
?>
				</select>
				</td></tr>
				<tr><td>Horam&egrave;tre au d&eacute;part&nbsp;: (*)</td><td align="left"><input type="number" step="0.01" id="horametre_depart" name="horametre_depart" value ="<?php echo $tab_hora_end[0]; ?>" required /></td></tr>
				<tr><td>Horam&egrave;tre &agrave; la fin&nbsp;: (*)</td><td align="left"><input type="number" step="0.01" id="horametre_arrivee" name="horametre_arrivee" required /></td></tr>
				<tr><td>Terrain de d&eacute;part&nbsp;: (*)</td><td align="left"><input type="text" id="terrain_depart_oaci" name="terrain_depart_oaci" value ="<?php echo $tab_terrain_arrivee_oaci[0]; ?>" required /></td></tr>
				<tr><td>Terrain d'arriv&eacute;e&nbsp;: (*)</td><td align="left"><input type="text" id="terrain_arrivee_oaci" name="terrain_arrivee_oaci" required /></td></tr>
				<tr><td>Carburant au d&eacute;part (litres en arrivant &agrave; l'avion)&nbsp;: (*)</td><td align="left"><input type="number" id="carburant_depart" name="carburant_depart" value ="<?php echo $tab_carburant_arrivee[0]; ?>" required /></td></tr>
				<tr><td>Carburant &agrave; l'arriv&eacute;e (litres au moment de partir apr&egrave;s le vol, et apr&egrave;s un &eacute;ventuel ajout de carburant)&nbsp;: (*)</td><td align="left"><input type="number" id="carburant_arrivee" name="carburant_arrivee" required /></td></tr>
				<tr><td>Carburant ajout&eacute;&nbsp;? (litres)&nbsp;:</td><td align="left"><input type="number" id="carburant_ajoute" name="carburant_ajoute" />&nbsp; Plein complet&nbsp;?&nbsp;<select id="leplein" name="leplein">
<?php
			$i = 0;
			foreach ($plein_complet_liste as $une_valeur) {
				echo '<option value="' . $une_valeur . '">' . $plein_complet_liste_texte[$i] . '</option>';
				$i++;
				}
?>
				</select></td></tr>
				<tr><td>Remarques ULM&nbsp;: </td><td align="left"><textarea id=remarques" name="remarques" rows=8></textarea></td></tr>
				<tr><td>Notes pilote&nbsp;: </td><td align="left"><textarea id=notes_pilote" name="notes_pilote" rows=8></textarea></td></tr>
				<tr><td colspan=2 align="center"><input type="submit" id="submitUnVol" /><input type="button" id="attenteEnvoi" value="Envoi en cours..." style="display:none;background:orange"/><br />(*) => champ obligatoire</td></tr>
			</tbody>
		</table>
    </form>
	<script>
    document.getElementById('formUnVol').addEventListener('submit', function() {
        document.getElementById('submitUnVol').disabled = true;
		document.getElementById('submitUnVol').style.display = 'none';
		document.getElementById('attenteEnvoi').style.display = 'block';
    });
	</script>

    <?php
}

// Ajouter une note de frais (téléchargement du fichier, saisie du montant et du motif
function gd_carnet_ajoute_frais () {
	global $wpdb;
	global $tableNotesDeFrais;
	$autoAjoutNoteDeFrais = getPrevalFlagValue ();
	
	$current_user = wp_get_current_user();
	$select_num_pilote_query = $wpdb->prepare('SELECT id, actif, niveau_admin FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
	$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
	if ($select_num_pilote == null) {
		echo '<center><h2><font color="red">Veuillez vous identifier</font></h2></center>';
		return;
		}
	$pilote_id = $select_num_pilote[0]->id;
	
	if ($select_num_pilote[0]->actif == false) {
		echo '<center><h2><font color="red">Compte d&eacute;sactiv&eacute;, contactez votre administrateur</font></h2></center>';
		return;
		}
		
	// si le formulaire a été soumis, ajoute la note dans la base de données
    if (isset($_FILES['facture'])) {
		// Récupération et nettoyage des entrées
		if (isset($_POST['montant_note']))
			$montant_note = $_POST['montant_note'];
		else
			$montant_note = 0;
		if (!is_numeric($montant_note))
			$montant_note = 0;
		if (isset($_POST['motif_note']))
			$motif_note = sanitize_text_field($_POST['motif_note']);
		else
			$motif_note = '';
		if ($_FILES['facture'] != null)
				$nom_facture = sanitize_file_name($_FILES['facture']['name']);
			else
				$nom_facture = null;
			$wpdb->insert(
			$wpdb->prefix .'gd_table_frais',
				array(
					'pilote' => $pilote_id,
					'description' => $motif_note,
					'valeur' => $montant_note,
					'valide' => $autoAjoutNoteDeFrais
					)
				);
			$uploadFileId = $wpdb->insert_id;
			$wpdb->insert(
			$wpdb->prefix .'gd_table_fichiers',
				array(
					'clef_autre' => $uploadFileId,
					'table_autre' => $tableNotesDeFrais,
					'fichier' => $nom_facture,
					'description' => 'Note de frais'
					)
				);
			$fileNewName = $wpdb->insert_id;
			$upload_dir   = wp_upload_dir(null, false);
			$monRepertoire = $upload_dir['basedir'] . '/carnetdevols/fichiers';
			$monFichier = $monRepertoire . '/' . $fileNewName;
			if (!is_dir($monRepertoire))
				mkdir ($monRepertoire);
			move_uploaded_file($_FILES['facture']['tmp_name'], $monFichier);
			if ($autoAjoutNoteDeFrais) {	// Si ajout automatique de la note de frais au crédit du pilote, on le crédite.
					$wpdb->insert(
						$wpdb->prefix . 'gd_table_pilote_comptes',
						array(
							'id' => NULL,
							'pilote' => $pilote_id,
							'motif' => 'Remboursement de frais',
							'auteur' => $pilote_id,
							'credit' => $montant_note,
							'debit' => 0,
							'id_frais' => $fileNewName,
							'date' => current_time('mysql', 1)
							)
						);
					}
			echo '<br /><hr />Votre note a &eacute;t&eacute; enregistr&eacute;e, merci.<hr /><br />';
			if (get_option( 'dest_notes' )) {
				$destinataire = get_option( 'dest_notes' );
				$texteCourriel = "Nouvelle note de frais enregistrée :\n\n";
				$texteCourriel .= 'Pilote : ' . $current_user->display_name . "\n";
				$texteCourriel .= 'Montant : ' . $montant_note . "\n";
				$texteCourriel .= 'Motif : ' . $motif_note . "\n";
				$texteCourriel .= 'Fichier : ' . $nom_facture . "\n";
				$tempFile = $monRepertoire . '/' . $nom_facture;
				copy($monFichier, $tempFile);
				$resu_mail = wp_mail ($destinataire, 'Note de frais', $texteCourriel, '', $tempFile);
				unlink($tempFile);
				}
			return;
		}
?>
	<form method="post" action="" enctype="multipart/form-data" id="formNote" >
		<table border="1">
			<tbody>
				<tr><td><?php _e('Pilote&nbsp;');?>: </td><td align="left"><?php echo $current_user->display_name; ?></td></tr>
				<tr><td>Montant de la note&nbsp;:</td><td align="left"><input type="number" step="0.01" id="montant_note" name="montant_note" /></td></tr>
				<tr><td>Motif / explications&nbsp;: </td><td align="left"><textarea id="motif_note" name="motif_note" rows=8 cols=45></textarea></td></tr>
				<tr><td>Facture / ticket (*)&nbsp;:</td><td align="center"><input type="file" id="facture" name="facture" required/></td></tr>
				<tr><td colspan=2 align="center"><input type="submit" id="submitNote"/><input type="button" id="attenteNote" value="Envoi en cours..." style="display:none;background:orange"/><br />(*) => champ obligatoire</td></tr>
			</tbody>
		</table>
    </form>
	<script>
    document.getElementById('formNote').addEventListener('submit', function() {
        document.getElementById('submitNote').disabled = true;
		document.getElementById('submitNote').style.display = 'none';
		document.getElementById('attenteNote').style.display = 'block';
    });
	</script>
<?php
}

// Affichage de la liste des notes de frais
function gd_carnet_liste_frais() {
	global $wpdb;
	global $nbMaxAff;
	global $tableNotesDeFrais;
	global $niveauTresorier;

	if (isset($_GET['note'])) {
		$current_user = wp_get_current_user();
		$select_num_pilote_query = $wpdb->prepare('SELECT id, niveau_admin FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
		$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
		if ($select_num_pilote == null) {
			echo '<center><h2><font color="red">Veuillez vous identifier</font></h2></center>';
			return;
			}
		if (isset($_GET['swapto'])) {
			if (($select_num_pilote[0]->niveau_admin & $niveauTresorier) != 0) {	// Vérification pour s'assurer que c'est bien un trésorier......
				if (!strcmp ($_GET['swapto'], 'oui')) {
					$prepareGetIdPilote = $wpdb->prepare('SELECT pilote, valeur, date_note FROM ' . $wpdb->prefix .'gd_table_frais WHERE id=%d', $_GET['note']);
					$leIdPilote = $wpdb->get_results($prepareGetIdPilote);
					$nouveauValide = true;
					$wpdb->insert(
						$wpdb->prefix . 'gd_table_pilote_comptes',
						array(
							'id' => NULL,
							'pilote' => $leIdPilote[0]->pilote,
							'motif' => 'Remboursement de frais',
							'auteur' => $select_num_pilote[0]->id,
							'credit' => $leIdPilote[0]->valeur,
							'debit' => 0,
							'id_frais' => $_GET['note'],
							'date' => $leIdPilote[0]->date_note
							)
						);
					}
				else {
					$wpdb->delete( $wpdb->prefix .'gd_table_pilote_comptes', array( 'id_frais' => $_GET['note'] ));
					$nouveauValide = false;
					}
				$wpdb->update(
					$wpdb->prefix .'gd_table_frais',
					array(
						'valide' => $nouveauValide
						),
					array(
						'id' => $_GET['note']
						)
					);
				}
			}
		$prepareLaNote = $wpdb->prepare('SELECT ' . $wpdb->prefix .'gd_table_frais.id, date_note, nom_pilote, description, valeur, valide FROM ' . $wpdb->prefix .'gd_table_frais,  ' . $wpdb->prefix .'gd_table_pilote WHERE ' . $wpdb->prefix . 'gd_table_pilote.id=' . $wpdb->prefix .'gd_table_frais.pilote AND ' . $wpdb->prefix .'gd_table_frais.id=%d', $_GET['note']);
		$laNote = $wpdb->get_results($prepareLaNote);
		
		if ($laNote == null) {
			echo '<hr /><h1>ERREUR DE SAISIE</h1></hr>';
			exit;
			}
		
		$prepareLeFichier = $wpdb->prepare('SELECT id, fichier FROM ' . $wpdb->prefix .'gd_table_fichiers WHERE table_autre=%d AND clef_autre=%d', $tableNotesDeFrais, $_GET['note']);
		$leFichier = $wpdb->get_results($prepareLeFichier);
		echo '<table border="1">';
		echo '<tbody>';
		echo '<tr><td>Date&nbsp;:</td><td>' . $laNote[0]->date_note . '</td></tr>';
		echo '<tr><td>Pilote&nbsp;:</td><td>' . $laNote[0]->nom_pilote . '</td></tr>';
		echo '<tr><td>Montant&nbsp;:</td><td>' . $laNote[0]->valeur . '</td></tr>';
		echo '<tr><td>Motif&nbsp;:</td><td>' . $laNote[0]->description . '</td></tr>';
		echo '<tr><td>Note&nbsp;:</td><td><a href="?fichier_note=' . $leFichier[0]->id . '">' . $leFichier[0]->fichier . '</a></td></tr>';
		if (($select_num_pilote[0]->niveau_admin & $niveauTresorier) != 0) {
			if ($laNote[0]->valide)
				echo '<tr><td>Validit&eacute;&nbsp;:</td><td bgcolor="lightgreen"><a href="?note=' . $_GET['note'] . '&swapto=non">oui</a></td></tr>';
			else
				echo '<tr><td>Validit&eacute;&nbsp;:</td><td bgcolor="#ffaaaa"><a href="?note=' . $_GET['note'] . '&swapto=oui">non</a></td></tr>';
			}
		else {
			if ($laNote[0]->valide)
				echo '<tr><td>Validit&eacute;&nbsp;:</td><td bgcolor="lightgreen">oui</td></tr>';
			else
				echo '<tr><td>Validit&eacute;&nbsp;:</td><td bgcolor="#ffaaaa">non</td></tr>';
			}
		echo '</tbody>';
		echo '</table>';
		$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]";
		$tab_link = explode ('/', $_SERVER['REQUEST_URI']);
		$sz = sizeof ($tab_link);
		$resu = '';
		for ($i = 0; $i < $sz -1; $i++) {
			$resu .= $tab_link[$i] . '/';
			}
		echo '<a href="' . $actual_link . $resu . '">Retour &agrave; la liste</a>';
		return;
		}

	// Pas de paramètre => pas besoin de préparer
	$listeFrais = $wpdb->get_results('SELECT ' . $wpdb->prefix .'gd_table_frais.id, date_note, nom_pilote, description, valeur, valide FROM ' . $wpdb->prefix .'gd_table_frais,  ' . $wpdb->prefix .'gd_table_pilote WHERE ' . $wpdb->prefix .'gd_table_pilote.id=' . $wpdb->prefix .'gd_table_frais.pilote ORDER BY date_note DESC LIMIT ' . $nbMaxAff);
	echo '<table border="1">';
	echo '<tbody>';
	echo '<tr><td>Date</td><td>Pilote</td><td>Montant</td><td>Motif</td>';
	echo '<td>Valid&eacute;e&nbsp;?</td>';
	echo '</tr>';
	foreach ($listeFrais AS $unFrais) {
		echo '<tr>';
		echo '<td><a href="?note=' . $unFrais->id . '">' . $unFrais->date_note . '</a></td>';
		echo '<td>' . $unFrais->nom_pilote . '</td>';
		echo '<td align="center">' . $unFrais->valeur . '</td>';
		echo '<td>' . $unFrais->description . '</td>';
		if ($unFrais->valide)
			echo '<td align="center" bgcolor="lightgreen">oui</td>';
		else
			echo '<td align="center" bgcolor="#ffaaaa">non</td>';
		echo '</tr>';
		}
	echo '</tbody>';
	echo '</table>';
}

function gd_carnet_menu() {
    // Ajoute une nouvelle page dans le menu d'administration
    add_menu_page(
        'Carnet de vols',    // Titre de la page
        'Carnet de vols ULM',    // Titre du menu
        'manage_options', // Niveau d'accès requis
        'carnet-de-vol', // Slug de la page
        'gd_carnet_plugin_page_content', // Fonction qui affiche le contenu de la page
        'dashicons-admin-plugins', // Icône du menu
        50 // Position dans le menu
    );
    
	// Ajoute une sous-page "Gestion des pilotes" à notre page du plugin
    add_submenu_page(
        'carnet-de-vol', // Slug de la page parente
        'Gestion des pilotes', // Titre de la sous-page
        'Gestion des pilotes', // Titre du menu
        'manage_options', // Niveau d'accès requis
        'carnet-plugin-settings', // Slug de la sous-page
        'gd_carnet_plugin_settings_gestion_pilotes' // Fonction qui affiche le contenu de la sous-page
    );
	
	// Ajoute une sous-page "Gestion de la liste des ULM" à notre page du plugin
    add_submenu_page(
        'carnet-de-vol', // Slug de la page parente
        'Gestion des ULM', // Titre de la sous-page
        'Gestion des ULM', // Titre du menu
        'manage_options', // Niveau d'accès requis
        'carnet-plugin-liste-ulm', // Slug de la sous-page
        'gd_carnet_settings_ulm' // Fonction qui affiche le contenu de la sous-page
    );
	
	// Ajoute une sous-page "Gestion de la liste des motifs des comptes" à notre page du plugin
    add_submenu_page(
        'carnet-de-vol', // Slug de la page parente
        'Gestion des messages des comptes', // Titre de la sous-page
        'Gestion des messages des comptes', // Titre du menu
        'manage_options', // Niveau d'accès requis
        'carnet-plugin-liste-messages-comptes', // Slug de la sous-page
        'gd_carnet_settings_messages_comptes' // Fonction qui affiche le contenu de la sous-page
    );
}

// Gestion de la liste des ULMs (en back office)
function gd_carnet_settings_ulm() {
	global $wpdb;
	$prepareUpdate = false;
	if (isset ($_POST['id'])) {
		$numid = sanitize_text_field($_POST['id']);
		if (!is_numeric($numid))
			return;
		$immatriculation = sanitize_text_field($_POST['immatriculation']);
		$modele = sanitize_text_field($_POST['modele']);
		$tarif_heure = sanitize_text_field($_POST['tarif_heure']);
		$remarques = sanitize_text_field($_POST['remarques']);
		$wpdb->update(
			$wpdb->prefix .'gd_table_ulm',
			array(
				'id' => $numid,
				'immatriculation' => $immatriculation,
				'modele' => $modele,
				'tarif_heure' => $tarif_heure,
				'remarques' => $remarques
				),
			array(
				'id' => $numid
				)
			);
		}
	else if (isset ($_POST['immatriculation'])) {
		$immatriculation = sanitize_text_field($_POST['immatriculation']);
		$modele = sanitize_text_field($_POST['modele']);
		$tarif_heure = sanitize_text_field($_POST['tarif_heure']);
		$remarques = sanitize_text_field($_POST['remarques']);
		$wpdb->insert(
			$wpdb->prefix .'gd_table_ulm',
			array(
				'id' => NULL,
				'immatriculation' => $immatriculation,
				'modele' => $modele,
				'tarif_heure' => $tarif_heure,
				'remarques' => $remarques
				)
			);
		}
	else if (isset ($_GET['flipflopactif'])) {
		$numid = sanitize_text_field($_GET['flipflopactif']);
		if (!is_numeric($numid))	// Si numid n'est pas numérique, on a un gros problème.....
			return;
		$doFlipFlop = $wpdb->prepare('UPDATE ' . $wpdb->prefix .'gd_table_ulm SET actif = NOT actif WHERE id=%d', $numid);
		$wpdb->query($doFlipFlop);
		}
	else if (isset ($_GET['ulm'])) {
		$prepareUpdate = true;
		$numid = sanitize_text_field($_GET['ulm']);
		if (!is_numeric($numid))	// Si numid n'est pas numérique, on a un gros problème.....
			return;
		$edit_ulm_actif_query = $wpdb->prepare('SELECT id, immatriculation, modele, tarif_heure, remarques FROM ' . $wpdb->prefix .'gd_table_ulm WHERE id=%d', $numid);
		$edit_ulm = $wpdb->get_results($edit_ulm_actif_query);
		}
	// Pas de paramètre => pas besoin de prepare
	$liste_ulm = $wpdb->get_results( 'SELECT id, immatriculation, modele, actif, tarif_heure, remarques FROM ' . $wpdb->prefix .'gd_table_ulm ORDER BY modele ASC');
?>
	<h1>Gestion des ULM</h1>
	<hr />
	<table border="1">
			<tbody>
				<tr><td>Immatriculation</td><td>Mod&egrave;le</td><td>Actif</td><td>Prix &agrave; l'heure</td><td>Remarques</td><td>id</td></tr>
<?php
	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'] . '?page=' . $_GET['page'];
	foreach ($liste_ulm as $un_ulm) {
		echo '<tr><td><a href=' . $actual_link . '&ulm=' . $un_ulm->id . '>' . $un_ulm->immatriculation . '</a></td><td>' . $un_ulm->modele . '</td><td bgcolor="' . (($un_ulm->actif == 1) ? 'lightgreen' : '#FF6666') . '"><a href="' . $actual_link . '&flipflopactif=' . $un_ulm->id . '" />' . (($un_ulm->actif == 1) ? 'oui' : 'non') . '</a></td><td align="right">' . $un_ulm->tarif_heure . '&nbsp;&euro;</td><td>' . $un_ulm->remarques . '</td><td>' . $un_ulm->id . '</td></tr>';
		}
?>
			</tbody>
		</table>
		<hr />
<?php
	if ($prepareUpdate) {
		echo 'Modifier un ULM&nbsp;:<br />';
		}
	else {
		echo 'Ajouter un ULM&nbsp;:<br />';
		}
?>
		<form method="post" action="">
		<table border="1">
			<tbody>
				<tr><td>Immatriculation</td><td>Mod&egrave;le</td><td>Prix &agrave; l'heure</td><td>Remarques</td><td></td></tr>
				<tr>
<?php
	if ($prepareUpdate) {
		echo '<td><input type="hidden" name="id" id="id" value="' . $edit_ulm[0]->id . '" /><input type="text" name="immatriculation" id="immatriculation" value="' . $edit_ulm[0]->immatriculation . '"/></td>';
		echo '<td><input type="text" name="modele" id = "modele" value="' . $edit_ulm[0]->modele . '"/></td>';
		echo '<td><input type="text" name="tarif_heure" id = "tarif_heure" value="' . $edit_ulm[0]->tarif_heure . '"/></td>';
		echo '<td><input type="text" name="remarques" id="remarques" value="' . $edit_ulm[0]->remarques . '"/></td>';
		echo '<td><input type="submit" value="Enregistrer" /></td>';
		}
	else {
?>
					<td><input type="text" name="immatriculation" id="immatriculation" /></td>
					<td><input type="text" name="modele" id = "modele" /></td>
					<td><input type="text" name="tarif_heure" id = "tarif_heure" /></td>
					<td><input type="text" name="remarques" id="remarques" /></td>
					<td><input type="submit" value="Enregistrer" /></td>
<?php
	}
?>
				</tr>
			</tbody>
		</table>
<?php
}

// Gestion des pilotes en back office
function gd_carnet_plugin_settings_gestion_pilotes() {
    // Affiche le contenu de la sous-page
	global $wpdb;
	global $niveauTresorier;
	global $niveauListAll;
	global $niveauMecano;
	global $nombreMoisPrec;
    
    echo '<h1>Gestion des pilotes</h1>';
	$editPilote = false;
	$niveau_pilote = 0;
	if (isset ($_POST['pilote'])) {
		// Récupération / nettoyage des entrées
        $id_pilote = sanitize_text_field($_POST['id_pilote']);
		if (isset($_POST['actif']))
			$actif = true;
		else
			$actif = false;
		$pilote = sanitize_text_field($_POST['pilote']);
		$nom_pilote = sanitize_text_field($_POST['nom_pilote']);
		$brevet = sanitize_text_field($_POST['brevet']);
		if (isset($_POST['lache'])) {
			$lache = true;
			$date_lache = sanitize_text_field($_POST['date_lache']);
			}
		else {
			$lache = false;
			$date_lache = '0000-00-00';
			}
		if (isset($_POST['emport'])) {
			$emport = true;
			$date_emport = sanitize_text_field($_POST['date_emport']);
			}
		else {
			$emport = false;
			$date_emport = '0000-00-00';
			}
		if (isset($_POST['listall']))
			$niveau_pilote |= $niveauListAll;
		if (isset($_POST['tresorier']))
			$niveau_pilote |= $niveauTresorier | $niveauListAll;	// Un trésorier voit forcément tous les comptes
		if (isset($_POST['volmecano']))
			$niveau_pilote |= $niveauMecano;
		$remarques = sanitize_textarea_field($_POST['remarques']);

		$wpdb->update(
			$wpdb->prefix .'gd_table_pilote',
			array(
				'nom_pilote' => $nom_pilote,
				'actif' => $actif,
				'brevet' => $brevet,
				'lache' => $lache,
				'date_lache' => $date_lache,
				'emport' => $emport,
				'date_emport' => $date_emport,
				'niveau_admin' => $niveau_pilote,
				'remarques' => $remarques
				),
			array(
				'user_login' => $pilote
				)
			);
		$wpdb->delete( $wpdb->prefix .'gd_table_pilote_ulm_lache', array( 'pilote' => $id_pilote ));
		if (isset($_POST['ulm'])) {
			foreach ($_POST['ulm'] as $selectedOption) {
				$wpdb->insert(
					$wpdb->prefix .'gd_table_pilote_ulm_lache',
					array(
						'id' => NULL,
						'pilote' => $id_pilote,
						'ulm' => $selectedOption,
						'date_lache' => current_time('mysql', 1)
						)
					);
				}
			}
		}
		else if (isset ($_GET['pilote']))
			$editPilote = true;
	$listePilotes = get_users();
	foreach ($listePilotes as $unPilote) {
		$select_un_pilote_query = $wpdb->prepare('SELECT id FROM ' . $wpdb->prefix .'gd_table_pilote WHERE user_login=%s', $unPilote->user_login);
		$select_un_pilote = $wpdb->get_results($select_un_pilote_query);
		if ($select_un_pilote == null) { // Si on n'a pas encore un carnet de vols pour cet utilisateur
				$table_name = $wpdb->prefix .'gd_table_pilote';
				$wpdb->insert(
					$table_name,
					array(
						'id' => NULL,
						'user_login' => $unPilote->user_login,
						'nom_pilote' => $unPilote->display_name,
						'lache' => 0,
						'remarques' => "Creation automatique"
						)
					);
				$pilote_id = $wpdb->insert_id;
			}
		}
		// Pas de paramètre => pas besoin de prepare
		$liste_pilotes = $wpdb->get_results( 'SELECT id, actif, user_login, nom_pilote, brevet, lache, date_lache, emport, date_emport, niveau_admin, remarques FROM ' . $wpdb->prefix .'gd_table_pilote ORDER BY nom_pilote ASC');
?>
<script type='text/javascript'>
function clicSurLache (lacheCheck) {
	if (lacheCheck.checked)
		document.getElementById("date_lache").required = true;
	else
		document.getElementById("date_lache").required = false;
}

function clicSurEmport (emportCheck) {
	if (emportCheck.checked)
		document.getElementById("date_emport").required = true;
	else
		document.getElementById("date_emport").required = false;
}

</script>
<hr />
	<table border="1">
			<tbody>
				<tr><td>Compte</td><td>Actif</td><td>Nom pilote</td><td>Brevet</td><td>Date l&acirc;ch&eacute;</td><td>Date emport</td><td>Remarques</td><td>ULM(s)</td><td>Niveau</td><td>Solde</td><td>Minutes mois en cours</td>
<?php
if ($nombreMoisPrec >= 2)
	echo '<td>Minutes mois pr&eacute;c&eacute;dent</td>';
if ($nombreMoisPrec == 3)
	echo '<td>Minutes il y a 2 mois</td>';
?>
				</tr>
<?php
$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'] . '?page=' . $_GET['page'];
foreach ($liste_pilotes as $un_pilote) {
		// $un_pilote->id provient d'un query => pas besoin de prepare
		$ulm_lache_query = $wpdb->prepare('SELECT ' . $wpdb->prefix .'gd_table_ulm.immatriculation, ' . $wpdb->prefix .'gd_table_ulm.modele, ' . $wpdb->prefix .'gd_table_ulm.actif, ' . $wpdb->prefix .'gd_table_pilote_ulm_lache.date_lache FROM ' . $wpdb->prefix .'gd_table_ulm, ' . $wpdb->prefix .'gd_table_pilote_ulm_lache WHERE ' . $wpdb->prefix .'gd_table_ulm.id=' . $wpdb->prefix .'gd_table_pilote_ulm_lache.ulm AND ' . $wpdb->prefix .'gd_table_pilote_ulm_lache.pilote=%d', $un_pilote->id);
		$ulm_lache = $wpdb->get_results($ulm_lache_query);
		echo '<tr><td><a href=' . $actual_link . '&pilote=' . $un_pilote->id . '>' . $un_pilote->user_login . '</a></td><td align="center" bgcolor="' . (($un_pilote->actif == 1) ? 'lightgreen' : '#FF6666') . '">' . (($un_pilote->actif == 1) ? 'oui' : 'non') . '</td><td>' . $un_pilote->nom_pilote . '</td><td>' . $un_pilote->brevet . '</td><td align="center" bgcolor="' . (($un_pilote->lache == 1) ? 'lightgreen' : '#FF6666') . '">' . (($un_pilote->lache == 1) ? $un_pilote->date_lache : 'n/a') . '</td><td align="center" bgcolor="' . (($un_pilote->emport == 1) ? 'lightgreen' : '#FF6666') . '">' . (($un_pilote->emport == 1) ? $un_pilote->date_emport : 'n/a') . '</td><td>'. $un_pilote->remarques . '</td><td>';
		$num_ulm = 0;
		foreach ($ulm_lache as $un_ulm) {
			if ($num_ulm != 0) echo '<br />';
			echo $un_ulm->immatriculation . ' ' . $un_ulm->modele . ' (' . $un_ulm->date_lache . ')';
			$num_ulm++;
			}
		echo '</td>';
		// $un_pilote->id provient d'un query => pas besoin de prepare
		$pilote_solde = $wpdb->get_results('SELECT SUM(credit) AS entrees, SUM(debit) AS sorties FROM ' . $wpdb->prefix .'gd_table_pilote_comptes WHERE pilote=' . $un_pilote->id);
		if ($pilote_solde == null)
			$le_solde = 0;
		else {
			if ($pilote_solde[0]->entrees == null)
				$entrees = 0;
			else
				$entrees = $pilote_solde[0]->entrees;

			if ($pilote_solde[0]->sorties == null)
				$sorties = 0;
			else
				$sorties = $pilote_solde[0]->sorties;
			
			$le_solde = $entrees - $sorties;
			}
		// $un_pilote->id provient d'un query => pas besoin de prepare
		$pilote_minutes_mois_en_cours = $wpdb->get_results('SELECT SUM(minutes_de_vol) AS minutes FROM ' . $wpdb->prefix .'gd_table_vols WHERE pilote=' . $un_pilote->id . ' AND MONTH(date_vol) = MONTH(now()) AND YEAR(date_vol) = YEAR(now())');
		if ($pilote_minutes_mois_en_cours == null) {
			$tot_minutes_cour = 0;
			}
		else if ($pilote_minutes_mois_en_cours[0]->minutes == null) {
			$tot_minutes_cour = 0;
			}
		else {
			$tot_minutes_cour = $pilote_minutes_mois_en_cours[0]->minutes;
			}
		// $un_pilote->id provient d'un query => pas besoin de prepare
		$pilote_minutes_mois_precedent = $wpdb->get_results('SELECT SUM(minutes_de_vol) AS minutes FROM ' . $wpdb->prefix .'gd_table_vols WHERE pilote=' . $un_pilote->id . ' AND MONTH(date_vol) = MONTH(DATE_ADD(NOW(),INTERVAL -1 MONTH)) AND YEAR(date_vol) = YEAR(DATE_ADD(NOW(),INTERVAL -2 MONTH))');
		if ($pilote_minutes_mois_precedent == null) {
			$tot_minutes_prec = 0;
			}
		else if ($pilote_minutes_mois_precedent[0]->minutes == null) {
			$tot_minutes_prec = 0;
			}
		else {
			$tot_minutes_prec = $pilote_minutes_mois_precedent[0]->minutes;
			}
		
		// $un_pilote->id provient d'un query => pas besoin de prepare
		$pilote_minutes_il_y_a_deux_mois = $wpdb->get_results('SELECT SUM(minutes_de_vol) AS minutes FROM ' . $wpdb->prefix .'gd_table_vols WHERE pilote=' . $un_pilote->id . ' AND MONTH(date_vol) = MONTH(DATE_ADD(NOW(),INTERVAL -2 MONTH)) AND YEAR(date_vol) = YEAR(DATE_ADD(NOW(),INTERVAL -3 MONTH))');
		if ($pilote_minutes_il_y_a_deux_mois == null) {
			$tot_minutes_2_mois_prec = 0;
			}
		else if ($pilote_minutes_il_y_a_deux_mois[0]->minutes == null) {
			$tot_minutes_2_mois_prec = 0;
			}
		else {
			$tot_minutes_2_mois_prec = $pilote_minutes_il_y_a_deux_mois[0]->minutes;
			}
		
		$niveau = '';
		if ($un_pilote->niveau_admin != 0) {
			$nbNiveaux = 0;
			if (($un_pilote->niveau_admin & $niveauListAll) != 0) {
				$niveau .= 'Liste comptes';
				$nbNiveaux++;
				}
			if (($un_pilote->niveau_admin & $niveauTresorier) != 0) {
				if ($nbNiveaux++ > 0)
					$niveau .= '<br />';
				$niveau .= 'Tr&eacute;sorier';
				$nbNiveaux++;
				}
			if (($un_pilote->niveau_admin & $niveauMecano) != 0) {
				if ($nbNiveaux++ > 0)
					$niveau .= '<br />';
				$niveau .= 'Vol m&eacute;cano';
				$nbNiveaux++;
				}
			}
		echo '<td align=center>' . $niveau . '</td>';
		echo '<td align=center>' . $le_solde . '</td>';
		echo '<td align=center>' . $tot_minutes_cour . '</td>';
		if ($nombreMoisPrec >= 2)
			echo '<td align=center>' . $tot_minutes_prec . '</td>';
		if ($nombreMoisPrec == 3)
			echo '<td align=center>' . $tot_minutes_2_mois_prec . '</td>';
		echo '</tr>';
		}
		
?>
			</tbody>
		</table>
		<hr />
		<hr />
<?php
if ($editPilote) {
		echo '<form method="post" action="">';
		echo '<table border="0">';
		echo '<tbody>';
		$select_edit_pilote_query = $wpdb->prepare('SELECT id, actif, user_login, nom_pilote, brevet, lache, date_lache, emport, date_emport, niveau_admin, remarques FROM ' . $wpdb->prefix .'gd_table_pilote WHERE id=%d', sanitize_text_field($_GET['pilote']));
		$select_edit_pilote = $wpdb->get_results($select_edit_pilote_query);
		$select_liste_ulm = $wpdb->get_results( 'SELECT id, immatriculation, modele, actif FROM ' . $wpdb->prefix .'gd_table_ulm');
		$select_liste_lache_query = $wpdb->prepare('SELECT ulm, date_lache FROM ' . $wpdb->prefix .'gd_table_pilote_ulm_lache WHERE pilote=%d', sanitize_text_field($_GET['pilote']));
		$select_liste_lache = $wpdb->get_results($select_liste_lache_query);
?>
				<tr><td>Compte&nbsp;: </td><td align="left"><?php echo $select_edit_pilote[0]->user_login; ?><input type="hidden" id="pilote" name="pilote" value="<?php echo $select_edit_pilote[0]->user_login; ?>"  /><input type="hidden" id="id_pilote" name="id_pilote" value="<?php echo $select_edit_pilote[0]->id; ?>"  /></td></tr>
				<tr><td>Nom du pilote&nbsp;: </td><td align="left"><input type="text" id="nom_pilote" name="nom_pilote" value="<?php echo $select_edit_pilote[0]->nom_pilote; ?>" required /></td></tr>
				<tr><td>Actif&nbsp;? </td><td align="left"><input type="checkbox" id="actif" name="actif" <?php echo ($select_edit_pilote[0]->actif == 1)? 'checked' : ''; ?> /></td></tr>
				<tr><td>Brevet&nbsp;: </td><td align="left"><input type="text" id="brevet" name="brevet" value="<?php echo $select_edit_pilote[0]->brevet; ?>" /></td></tr>
				<tr><td>Lach&eacute;&nbsp;? </td><td align="left"><input type="checkbox" id="lache" name="lache" onclick="clicSurLache(this);" <?php echo ($select_edit_pilote[0]->lache == 1)? 'checked' : ''; ?> /></td></tr>
				<tr><td>Date du l&acirc;ch&eacute;&nbsp;: </td><td align="left"><input type="date" id="date_lache" name="date_lache" value="<?php echo $select_edit_pilote[0]->date_lache; ?>" <?php echo ($select_edit_pilote[0]->lache == 1)? 'required' : ''; ?> /></td></tr>
				<tr><td>Emport de passager&nbsp;? </td><td align="left"><input type="checkbox" id="emport" name="emport" onclick="clicSurEmport(this);" <?php echo ($select_edit_pilote[0]->emport == 1)? 'checked' : ''; ?> /></td></tr>
				<tr><td>Date emport passager&nbsp;: </td><td align="left"><input type="date" id="date_emport" name="date_emport" value="<?php echo $select_edit_pilote[0]->date_emport; ?>" <?php echo ($select_edit_pilote[0]->emport == 1)? 'required' : ''; ?> /></td></tr>
				<tr><td>Remarques&nbsp;: </td><td align="left"><textarea id="remarques" name="remarques" rows=8 cols=45><?php echo $select_edit_pilote[0]->remarques; ?></textarea></td></tr>
				<tr><td>ULM(s)&nbsp;: </td><td align="left"><select id="ulm" name="ulm[]" multiple>
<?php
	foreach ($select_liste_ulm as $un_ulm) {
		$isSelected = '';
		foreach ($select_liste_lache as $un_lache) {
			if ($un_ulm->id == $un_lache->ulm)
				$isSelected = 'selected';
			}
		echo '<option value=' . $un_ulm->id . ' ' . $isSelected . '>' . $un_ulm->modele . ' ' . $un_ulm->immatriculation . '</option>';
		}
?>
				</select></td></tr>
	<tr><td>Niveaux </td><td align="left"><input type="checkbox" id="listall" name="listall" <?php echo (($select_edit_pilote[0]->niveau_admin & $niveauListAll) != 0)? 'checked' : ''; ?>>&nbsp;Liste comptes</td></tr>
	<tr><td> </td><td align="left"><input type="checkbox" id="tresorier" name="tresorier" <?php echo (($select_edit_pilote[0]->niveau_admin & $niveauTresorier) != 0)? 'checked' : ''; ?>>&nbsp;Tr&eacute;sorier</td></tr>
	<tr><td> </td><td align="left"><input type="checkbox" id="volmecano" name="volmecano" <?php echo (($select_edit_pilote[0]->niveau_admin & $niveauMecano) != 0)? 'checked' : ''; ?>>&nbsp;Vol m&eacute;cano</td></tr>
			<tr><td colspan=2 align="center"><input type="submit" value="Enregistrer" /></td></tr>
			</tbody>
		</table>
    </form>
<?php
	}
}

// Gestion de la liste des motifs des comptes
function gd_carnet_settings_messages_comptes () {
	global $wpdb;
	
	if (isset ($_POST['motif'])) {
		echo 'Ajout de ' . $_POST['motif'] . '<hr />';
		$query_cherche_motif = $wpdb->prepare('SELECT id, motif FROM ' . $wpdb->prefix .'gd_table_motifs_comptes WHERE motif=%s' . $_POST['motif']);
		$select_motif = $wpdb->get_results($query_cherche_motif);
		if ($select_motif == null) {
			$wpdb->insert(
			$wpdb->prefix .'gd_table_motifs_comptes',
				array(
					'motif' => $_POST['motif']
					)
				);
			}
		}
	if (isset ($_GET['flipflopactif'])) {
		$numid = sanitize_text_field($_GET['flipflopactif']);
		$doFlipFlop = $wpdb->prepare('UPDATE ' . $wpdb->prefix .'gd_table_motifs_comptes SET actif = NOT actif WHERE id=%d', $numid);
		$wpdb->query($doFlipFlop);
		}
	echo '<br /><br />Les motifs disponibles&nbsp;:<br /><ul style="list-style-type:circle;">';
	$liste_motifs = $wpdb->get_results('SELECT id, motif, actif FROM ' . $wpdb->prefix .'gd_table_motifs_comptes ORDER BY motif ASC');	// Pas de variable, pas besoin de prepare
	echo'<table border=1><tr><th>Motif</th><th>actif</th></tr>';
	
	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'] . '?page=' . $_GET['page'];

	foreach ($liste_motifs as $un_motif) {
		if ($un_motif->actif)
			echo '<td>' . $un_motif->motif . '</td><td bgcolor="lightgreen" align="center"><a href="' . $actual_link . '&flipflopactif=' . $un_motif->id . '" />oui</a></td></tr>';
		else
			echo '<td>' . $un_motif->motif . '</td><td bgcolor="#FF6666" align="center"><a href="' . $actual_link . '&flipflopactif=' . $un_motif->id . '" />non</a></td></tr>';
		}
	echo '</table><hr />Ajouter un motif&nbsp;:';
	echo '<form method="post" action="">';
	echo '<input type="text" id="motif" name="motif" /><input type="submit" />';
	echo '</form>';
}

// Gestion menu général de gestion (backoffice)
function gd_carnet_plugin_page_content() {
	// Récupération du numéro de version officiel
	$plugin_data = get_plugin_data( __FILE__ );
	$versionActuelle = $plugin_data['Version'];
	
    // Affiche le contenu de la page
    echo '<h1>Gestion du carnet de vols</h1>';
    echo '<p>Plugin de gestion de carnets de vols multi-pilotes et multi-ULM</p>';

	if (isset($_POST['dest_notes'])) {
		$dest_email = filter_var($_POST['dest_notes'], FILTER_SANITIZE_EMAIL);
		if (get_option( 'dest_notes' ))
			update_option('dest_notes', $dest_email);
		else {
			delete_option( 'dest_notes' );
			add_option('dest_notes', $dest_email);
			}
		if (isset($_POST['prevalidation']))
			$prevalidation = 1;
		else
			$prevalidation = 0;
		}
	else {
		$prevalidation = getPrevalFlagValue ();
		}
	if (get_option( 'dest_notes' ))
		$destinataire = get_option( 'dest_notes' );
	else
		$destinataire = '';
	
	$getPreval = get_option( 'prevalidation' );
	if (($getPreval == 0) || ($getPreval == 1)) {
		update_option('prevalidation', $prevalidation);
		}
	else {
		delete_option( 'prevalidation' );
		add_option('prevalidation', $prevalidation);
		}
	if ($prevalidation)
		$is_checked = ' checked';
	else
		$is_checked = '';
	
	echo '<h2>Version du plugin&nbsp;: ' . $versionActuelle . '</h2><hr />';
    echo '<h1>Réglages g&eacute;n&eacute;raux</h1><hr />';
	echo '<form method="post" action="">';
	echo '<table>';
	echo '<tr><td>Pr&eacute;-validation des notes de frais&nbsp;?</td><td><input type="checkbox" id="prevalidation" name="prevalidation"' . $is_checked . ' /></td></tr>';
	echo '<tr><td>Destinataire des notes de frais&nbsp;:</td><td><input type="text" id="dest_notes" name="dest_notes" value="' . $destinataire . '" /></td></tr>';
	echo '<tr><td colspan=2><input type="submit" value="Enregistrer" /></td></tr>';
	echo '</table></form>';
}

function getPrevalFlagValue () {
global $autoAjoutNoteDeFrais;

$getPreval = get_option( 'prevalidation' );
if (($getPreval == 0) || ($getPreval == 1))
	$prevalidation = $getPreval;
else
	$prevalidation = $autoAjoutNoteDeFrais;
return $prevalidation;
}

// Gestion de l'ajout d'un entretien d'ULM dans la base
function gd_carnet_ajoute_entretien() {
	global $wpdb;
	
	$current_user = wp_get_current_user();
	$select_num_pilote_query = $wpdb->prepare('SELECT id, actif FROM ' . $wpdb->prefix .'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
	$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
	if ($select_num_pilote == null) {
		echo '<center><h2><font color="red">Veuillez vous identifier</font></h2></center>';
		return;
		}
	$pilote_id = $select_num_pilote[0]->id;
	
	if ($select_num_pilote[0]->actif == false) {
		echo '<center><h2><font color="red">Compte d&eacute;sactiv&eacute;, contactez votre administrateur</font></h2></center';
		return;
		}
		
// si le formulaire a été soumis, ajoute la transaction dans la base de données
    if (isset($_POST['mecanicien']) && isset($_POST['objet']) && isset($_POST['nature'])) {
		// Récupération / nettoyage des entrées
        $date_entretien = sanitize_text_field($_POST['date_entretien']);
		$ulm = sanitize_text_field($_POST['ulm']);
		$mecanicien = sanitize_text_field($_POST['mecanicien']);
        $horametre_debut = floatval(sanitize_text_field(str_replace(',' , '.', $_POST['horametre_debut'])));
		$horametre_fin = floatval(sanitize_text_field(str_replace(',' , '.', $_POST['horametre_fin'])));
		$objet = sanitize_textarea_field($_POST['objet']);
		$nature = sanitize_textarea_field($_POST['nature']);
		$reste = sanitize_textarea_field($_POST['reste']);
		$resultat = sanitize_textarea_field($_POST['resultat']);
		
		$heures_horametre_depart = (int)$horametre_debut;
		$minutes_horametre_depart = round(($horametre_debut - $heures_horametre_depart) * 100);
		$horadepart = (($heures_horametre_depart * 60) + $minutes_horametre_depart) * 60;

		$heures_horametre_arrivee = (int)$horametre_fin;
		$minutes_horametre_arrivee = round(($horametre_fin - $heures_horametre_arrivee) * 100);
		$horaarrivee = (($heures_horametre_arrivee * 60) + $minutes_horametre_arrivee) * 60;
		
		$duree_de_vol = ($horaarrivee - $horadepart) / 60;
		
		// Vérifications
		$aff_erreur = false;
		$msg_erreur = 'Erreur dans le formulaire&nbsp;:<br />';
		// Format de date
		$tab_date_vol = explode("-",$date_entretien);
		if (!checkdate($tab_date_vol[1], $tab_date_vol[2], $tab_date_vol[0])) {
			$aff_erreur = true;
			$msg_erreur .= 'Date de l\'entretien invalide<br />';
			}
		// Ordre des relevés de l'horamètre
		if ($horadepart > $horaarrivee) {
			$aff_erreur = true;
			$msg_erreur .= 'Horam&egrave;tre &agrave; la fin inf&eacute;rieur &agrave; celui de d&eacute;but<br />';
			}
		
		if ($aff_erreur) {
			echo $msg_erreur;
			echo '<hr /><br /><a href="javascript:history.back()">Retour pour corriger</a>';
			exit;
			}
		else {
			if ($_FILES['facture'] != null)
				$nom_facture = sanitize_file_name($_FILES['facture']['name']);
			else
				$nom_facture = null;
			$wpdb->insert(
			$wpdb->prefix .'gd_table_entretien',
				array(
					'ulm' => $ulm,
					'date_reparation' => $date_entretien,
					'horametre_debut' => $horadepart,
					'horametre_fin' => $horaarrivee,
					'mecano' => $mecanicien,
					'objet' => $objet,
					'nature' => $nature,
					'reste' => $reste,
					'resultat' => $resultat,
					'saisi_par' => $pilote_id,
					'facture' => $nom_facture,
					'date_creation' => current_time('mysql', 1)
					)
				);
			$fileNewName = $wpdb->insert_id;
			$upload_dir   = wp_upload_dir(null, false);
			$monRepertoire = $upload_dir['basedir'] . '/carnetdevols';
			$monFichier = $monRepertoire . '/' . $fileNewName;
			if (!is_dir($monRepertoire))
				mkdir ($monRepertoire);
			move_uploaded_file($_FILES['facture']['tmp_name'], $monFichier);
			echo '<br /><hr /><b>Votre saisie a &eacute;t&eacute; enregistr&eacute;e, merci.</b><hr /><br />';
			}

    }

// affiche le formulaire d'ajout d'un entretien
$liste_ulm_lache_actif_query = $wpdb->prepare('SELECT ' . $wpdb->prefix .'gd_table_ulm.id, immatriculation, modele FROM ' . $wpdb->prefix .'gd_table_ulm, ' . $wpdb->prefix .'gd_table_pilote_ulm_lache, ' . $wpdb->prefix .'gd_table_pilote WHERE ' . $wpdb->prefix .'gd_table_ulm.id=' . $wpdb->prefix .'gd_table_pilote_ulm_lache.ulm AND ' . $wpdb->prefix .'gd_table_ulm.actif=true AND ' . $wpdb->prefix .'gd_table_pilote_ulm_lache.pilote=' . $wpdb->prefix .'gd_table_pilote.id AND ' . $wpdb->prefix .'gd_table_pilote.user_login=%s', $current_user->user_login);
$liste_ulm_lache_actif = $wpdb->get_results($liste_ulm_lache_actif_query);
$nbULM = 0;
foreach ($liste_ulm_lache_actif as $un_ulm) {
	// $un_ulm->id provient d'un query => pas besoin de prepare
	$dernier_vol = $wpdb->get_results( 'SELECT TIME_FORMAT(SEC_TO_TIME(' . $wpdb->prefix .'gd_table_vols.horametre_arrivee), "%H.%i") AS hora_end, carburant_arrivee, terrain_arrivee_oaci FROM ' . $wpdb->prefix .'gd_table_vols WHERE ulm=' . $un_ulm->id . ' ORDER BY horametre_arrivee DESC LIMIT 1');
	$nbULM++;
	$tab_ulm_id[] = $un_ulm->id;
	if ($dernier_vol == null) {
		$tab_hora_end[] = 0;
		$tab_carburant_arrivee[] = 0;
		}
	else {
		$tab_hora_end[] = $dernier_vol[0]->hora_end;
		$tab_carburant_arrivee[] = $dernier_vol[0]->carburant_arrivee;
		}
	}
	if ($nbULM == 0) {
		$tab_hora_end[] = 0;
		$tab_carburant_arrivee[] = 0;
		}
	
	echo "<script type='text/javascript'>\n";
	echo 'let tab_ulm_id = [ ' . $tab_ulm_id[0];
	for ($i = 1; $i < $nbULM; $i++)
		echo ', ' . $tab_ulm_id[$i];
	echo " ];\n";
	echo 'let tab_hora_end = [ ' . $tab_hora_end[0];
	for ($i = 1; $i < $nbULM; $i++)
		echo ', ' . $tab_hora_end[$i];
	echo " ];\n";
	echo 'let tab_carburant_arrivee = [ ' . $tab_carburant_arrivee[0];
	for ($i = 1; $i < $nbULM; $i++)
		echo ', ' . $tab_carburant_arrivee[$i];
	echo " ];\n";
	echo "function onUlmChange (ulmSelect) {\n";
	echo 'for (numULM = 0; numULM < ' . $nbULM . '; numULM++) {' . "\n";
	echo 'if (tab_ulm_id[numULM] == ulmSelect.value) {' . "\n";
	echo 'document.getElementById("horametre_depart").value=tab_hora_end[numULM]' . "\n";
	echo 'document.getElementById("carburant_depart").value=tab_carburant_arrivee[numULM]' . "\n";
	echo "}\n";
	echo "}\n";
	echo "}\n";
	echo "</script>\n";
    ?>
    <form method="post" action="" enctype="multipart/form-data" id="formEntretien">
		<table border="0">
			<tbody>
				<tr><td><?php _e('Pilote&nbsp;');?>: </td><td align="left"><?php echo $current_user->display_name; ?></td></tr>
				<tr><td><?php _e('Date de l\'entretien&nbsp;');?>: (*)</td><td align="left"><input type="date" id="date_entretien" name="date_entretien" value="<?php echo date('Y-m-d'); ?>" required /></td></tr>
				<tr><td><?php _e('ULM&nbsp;');?>: (*)</td><td align="left">
				<select id="ulm" name="ulm" onchange="onUlmChange(this)">
<?php
	foreach ($liste_ulm_lache_actif as $un_ulm) {
		echo '<option value=' . $un_ulm->id . '>' . $un_ulm->modele . ' ' . $un_ulm->immatriculation . '</option>';
		}
?>
				</select>
				</td></tr>
				<tr><td>Mécanicien(s)&nbsp;: (*)</td><td align="left"><input type="text" id="mecanicien" name="mecanicien" required /></td></tr>
				<tr><td>Horam&egrave;tre au d&eacute;but&nbsp;: (*)</td><td align="left"><input type="number" step="0.01" id="horametre_debut" name="horametre_debut" value ="<?php echo $tab_hora_end[0]; ?>" required /></td></tr>
				<tr><td>Horam&egrave;tre &agrave; la fin&nbsp;: (*)</td><td align="left"><input type="number" step="0.01" id="horametre_fin" name="horametre_fin" required /></td></tr>
				<tr><td>Objet (pourquoi cet entretien / r&eacute;paration) (*)&nbsp;: </td><td align="left"><textarea id=objet" name="objet" rows=8 required></textarea></td></tr>
				<tr><td>Nature de l'entretien (ce qui a &eacute;t&eacute; fait) (*)&nbsp;: </td><td align="left"><textarea id=nature" name="nature" rows=8 required></textarea></td></tr>
				<tr><td>Reste &agrave; faire&nbsp;: </td><td align="left"><textarea id=reste" name="reste" rows=8></textarea></td></tr>
				<tr><td>R&eacute;sultat (*)&nbsp;:</td><td align="left"><textarea id=resultat" name="resultat" rows=8 required></textarea></td></tr>
				<tr><td>Facture(s) (.zip si plusieurs factures)&nbsp;:</td><td align="left"><input type="file" id="facture" name="facture" /></td></tr>
				<tr><td colspan=2 align="center"><input type="submit" id="submitEntretien" /><input type="button" id="attenteEnretien" value="Envoi en cours..." style="display:none;background:orange"/><br />(*) => champ obligatoire</td></tr>
			</tbody>
		</table>
    </form>
	<script>
    document.getElementById('formEntretien').addEventListener('submit', function() {
        document.getElementById('submitEntretien').disabled = true;
		document.getElementById('submitEntretien').style.display = 'none';
		document.getElementById('attenteEnretien').style.display = 'block';
    });
	</script>
    <?php
}

// Affichage du carnet d'entretien d'un ULM (paramètre 'ulm' avec ID de l'ULM)
function gd_carnet_display_entretien_ulm($atts = array(), $content = null, $tag = '') {
	global $nbMaxAff;
	global $wpdb;
	
	$type_aff=0;
	
	$atts = array_change_key_case((array) $atts, CASE_LOWER );
	$numUlm = esc_html($atts['ulm']);
	

	
	if (isset ($_GET['entretien'])) {
		$type_carnet = 1;
		if (isset ($_GET['type_carnet']))
			$type_carnet = $_GET['type_carnet'];
		if (($type_carnet != 0) && ($type_carnet != 1))
			$type_carnet = 1;
		gd_carnet_display_un_entretien (sanitize_text_field($_GET['entretien']), $type_carnet);	// Cette fonction nettoie elle-même ses entrées
		return;
		}

    ?>
    <div class="wrap">
	<?php
	$entretiens_query = 
		$entretiens_query = "SELECT " . $wpdb->prefix . "gd_table_entretien.id, date_reparation, TIME_FORMAT(SEC_TO_TIME(horametre_debut), '%H,%i') AS hora_debut, TIME_FORMAT(SEC_TO_TIME(horametre_fin), '%H,%i') AS hora_fin, mecano, objet, nature, reste, resultat, nom_pilote, facture, " . $wpdb->prefix . "gd_table_ulm.modele, " . $wpdb->prefix . "gd_table_ulm.immatriculation FROM " . $wpdb->prefix . "gd_table_entretien, " . $wpdb->prefix . "gd_table_pilote, " . $wpdb->prefix . "gd_table_ulm WHERE " . $wpdb->prefix . "gd_table_pilote.id=" . $wpdb->prefix . "gd_table_entretien.saisi_par AND " . $wpdb->prefix . "gd_table_ulm.id=" . $wpdb->prefix . "gd_table_entretien.ulm AND ";
		$entretiens_query .= $wpdb->prepare('ulm=%d ORDER BY date_reparation DESC LIMIT %d', $numUlm, $nbMaxAff);
		$entretiens  = $wpdb->get_results($entretiens_query);
		if ($entretiens == null) {
			$leULM = $wpdb->get_results('SELECT modele, immatriculation FROM ' . $wpdb->prefix . 'gd_table_ulm WHERE id=' . $numUlm);
			echo '<h1>Carnet d\'entretien du ' . $leULM[0]->modele . ' ' . $leULM[0]->immatriculation . '</h1>';
			}
		else
			echo '<h1>Carnet d\'entretien du ' . $entretiens[0]->modele . ' ' . $entretiens[0]->immatriculation . '</h1>';

		$urlCsv = '?csv=oui';
		if ($type_aff == 1)
			$urlCsv .= '&ulm=' . $num_ulm;
		echo '<a href="' . $urlCsv . '" >T&eacute;l&eacute;charger le carnet d\'entretien</a><br /><br />';
	?>
        <table border="1">
            <thead>
                <tr>
                    <th>Date<br />de l'entretien / r&eacute;paration</th>
					<th>M&eacute;canicien</th>
                    <th>Horam&egrave;tre au d&eacute;but</th>
					<th>Horam&egrave;tre &agrave; la fin</th>
					<th>Objet de l'intervention</th>
					<th>Nature de l'intervention</th>
					<th>R&eacute;sultat</th>
					<th>Reste &agrave; faire</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($entretiens as $un_entretien) {
                    ?>
                    <tr>
                        <td align="center"><?php echo '<a href=?entretien=' . $un_entretien->id . '&type_carnet=' . $type_aff . '>' . $un_entretien->date_reparation . '</a>'; ?></td>
						<td align="center"><?php echo stripslashes($un_entretien->mecano); ?></td>
						<td align="center"><?php echo $un_entretien->hora_debut; ?></td>
						<td align="center"><?php echo $un_entretien->hora_fin; ?></td>
<?php
						if (strlen($un_entretien->objet) > 20) {
							$objet = substr(stripslashes($un_entretien->objet),0,17);
							echo '<td align="center">' . $objet . ' <b>(...)</b></td>';
							}
						else
							echo '<td align="center">' . stripslashes($un_entretien->objet) . '</td>';
						if (strlen($un_entretien->nature) > 20) {
							$nature = substr(stripslashes($un_entretien->nature),0,17);
							echo '<td align="center">' . $nature . ' <b>(...)</b></td>';
							}
						else
							echo '<td align="center">' . stripslashes($un_entretien->nature) . '</td>';
						if (strlen($un_entretien->resultat) > 20) {
							$resultat = substr(stripslashes($un_entretien->resultat),0,17);
							echo '<td align="center">' . $resultat . ' <b>(...)</b></td>';
							}
						else
							echo '<td align="center">' . stripslashes($un_entretien->resultat) . '</td>';
						if (strlen($un_entretien->reste) > 20) {
							$reste = substr(stripslashes($un_entretien->reste),0,17);
							echo '<td align="center">' . $reste . ' <b>(...)</b></td>';
							}
						else
							echo '<td align="center">' . stripslashes($un_entretien->reste) . '</td>';
?>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Affichage des détails d'un entretien
function gd_carnet_display_un_entretien ($numentretien, $type_carnet) {	// type_carnet : 0 => pilote, 1 => ulm
	global $wpdb;
	
	if (($type_carnet != 0) && ($type_carnet != 1))
		$type_carnet = 1;
	
	$current_user = wp_get_current_user();
	$cet_entretiens_query = "SELECT " . $wpdb->prefix . "gd_table_entretien.id, date_reparation, TIME_FORMAT(SEC_TO_TIME(horametre_debut), '%H,%i') AS hora_debut, TIME_FORMAT(SEC_TO_TIME(horametre_fin), '%H,%i') AS hora_fin, mecano, objet, nature, reste, resultat, nom_pilote, facture, " . $wpdb->prefix . "gd_table_ulm.modele, " . $wpdb->prefix . "gd_table_ulm.immatriculation, " . $wpdb->prefix . "gd_table_entretien.ulm FROM " . $wpdb->prefix . "gd_table_entretien, " . $wpdb->prefix . "gd_table_pilote, " . $wpdb->prefix . "gd_table_ulm WHERE " . $wpdb->prefix . "gd_table_pilote.id=" . $wpdb->prefix . "gd_table_entretien.saisi_par AND " . $wpdb->prefix . "gd_table_ulm.id=" . $wpdb->prefix . "gd_table_entretien.ulm AND ";
	$cet_entretiens_query .= $wpdb->prepare($wpdb->prefix . 'gd_table_entretien.id=%d', $numentretien);
	$cet_entretien  = $wpdb->get_results($cet_entretiens_query);
	?>
	<h1>D&eacute;tails d'un entretien</h1>
	<table border="1">
		<tbody>
			<tr><td>Date du l'entretien&nbsp;: </td><td align="center"><?php echo $cet_entretien[0]->date_reparation; ?></td></tr>
			<tr><td>M&eacute;canicien&nbsp;: </td><td align="center"><?php echo stripslashes($cet_entretien[0]->mecano); ?></td></tr>
			<tr><td>Horam&egrave;tre au d&eacute;but&nbsp;: </td><td align="center"><?php echo $cet_entretien[0]->hora_debut; ?></td></tr>
			<tr><td>Horam&egrave;tre &agrave; la fin&nbsp;: </td><td align="center"><?php echo $cet_entretien[0]->hora_fin; ?></td></tr>
			<tr><td>Objet de l'intervention&nbsp;: </td><td align="left"><?php echo nl2br(stripslashes($cet_entretien[0]->objet)); ?></td></tr>
			<tr><td>Nature de l'intervention&nbsp;: </td><td align="left"><?php echo nl2br(stripslashes($cet_entretien[0]->nature)); ?></td></tr>
			<tr><td>R&eacute;sultat de l'intervention&nbsp;: </td><td align="left"><?php echo nl2br(stripslashes($cet_entretien[0]->resultat)); ?></td></tr>
			<tr><td>Reste &agrave; faire&nbsp;: </td><td align="left"><?php echo nl2br(stripslashes($cet_entretien[0]->reste)); ?></td></tr>
<?php
		if ($cet_entretien[0]->facture != null)
			echo '<tr><td>Facture&nbsp;: </td><td align="center"><a href="?facture=' . $cet_entretien[0]->id . '&ulm=' . $cet_entretien[0]->ulm . '">' . $cet_entretien[0]->facture . '</a></td></tr>'
?>
		</tbody>
    </table>
	<?php
	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]";
	$tab_link = explode ('/', $_SERVER['REQUEST_URI']);
	$sz = sizeof ($tab_link);
	$resu = '';
	for ($i = 0; $i < $sz -1; $i++) {
		$resu .= $tab_link[$i] . '/';
		}
	echo '<a href="' . $actual_link . $resu . '">Retour &agrave; la liste</a>';
}

// Ajouter une note de frais (téléchargement du fichier, saisie du montant et du motif
function gd_carnet_heures_pilotes () {
	global $wpdb;
	$nb_mois = 5;
	
	$current_user = wp_get_current_user();
	$select_num_pilote_query = $wpdb->prepare('SELECT id, actif, niveau_admin FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE user_login=%s', $current_user->user_login);
	$select_num_pilote = $wpdb->get_results($select_num_pilote_query);
	if ($select_num_pilote == null) {
		echo '<center><h2><font color="red">Veuillez vous identifier</font></h2></center>';
		return;
		}
	$pilote_id = $select_num_pilote[0]->id;
	
	if ($select_num_pilote[0]->actif == false) {
		echo '<center><h2><font color="red">Compte d&eacute;sactiv&eacute;, contactez votre administrateur</font></h2></center>';
		return;
		}

	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]";
	$tab_link = explode ('/', $_SERVER['REQUEST_URI']);
	$sz = sizeof ($tab_link);
	$resu = '';
	for ($i = 0; $i < $sz -1; $i++) {
		$resu .= $tab_link[$i] . '/';
		}
	if (isset ($_GET['offset']))
		$offset = $_GET['offset'];
	else
		$offset = 0;
	if (!is_numeric($offset))
		$offset = 0;
	$prev = $offset + 1;
	$suiv = $offset - 1;
	$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]" . $resu . '?offset=';
	// Pas de paramètre, pas besoin de prepare
	$wpdb->query('SET lc_time_names = "fr_fr"');
	$liste_pilotes = $wpdb->get_results( 'SELECT id, user_login, nom_pilote FROM ' . $wpdb->prefix . 'gd_table_pilote WHERE actif=true ORDER BY nom_pilote ASC');
	echo '<table border="1"><tbody>';
	if ($offset == 0)
		echo '<tr><td style="border-right-style: hidden" align="left" colspan=' . $nb_mois + 2 . '>&nbsp;&nbsp;<a href="' . $actual_link . $prev . '" style="text-decoration:none">&lt;--</a></td><td style="border-left-style: hidden" align="right">&nbsp;</td></tr>';
	else
		echo '<tr><td style="border-right-style: hidden" align="left" colspan=' . $nb_mois + 2 . '>&nbsp;&nbsp;<a href="' . $actual_link . $prev . '" style="text-decoration:none">&lt;--</a></td><td style="border-left-style: hidden" align="right"><a href="' . $actual_link . $suiv . '" style="text-decoration:none">--&gt;</a>&nbsp;&nbsp;</td></tr>';
	echo '<tr><td align="center">Pilote</td>';
	for ($minus_mois = $nb_mois; $minus_mois >= 0; $minus_mois--) {
		$offset_mois = $minus_mois + (($nb_mois + 1) * $offset);
		$query_nom_mois = $wpdb->get_results( 'SELECT YEAR(DATE_SUB(curdate(), INTERVAL ' . $offset_mois . ' MONTH)) AS annee, MONTHNAME(DATE_SUB(curdate(), INTERVAL ' . $offset_mois . ' MONTH)) AS mois');
		echo '<td align="center">' . $query_nom_mois[0]->mois . '<br />' . $query_nom_mois[0]->annee . '</td>';
		}
	echo '<td align="center">Total</td></tr>';
	$num_col = 0;
	for ($minus_mois = $nb_mois; $minus_mois >= 0; $minus_mois--) {
		$tot_col[$num_col] = 0;
		$num_col++;
		}
	foreach ($liste_pilotes as $un_pilote) {
		$tot_pilote = 0;
		echo '<tr><td>' . $un_pilote->nom_pilote . '</td>';
		$num_col = 0;
		for ($minus_mois = $nb_mois; $minus_mois >= 0; $minus_mois--) {
			$offset_mois = $minus_mois + (($nb_mois + 1) * $offset);
			$queryMois = $wpdb->prepare('SELECT nom_pilote, SUM(minutes_de_vol) AS minutes FROM wp_gd_table_vols, wp_gd_table_pilote WHERE pilote=%d AND pilote=wp_gd_table_pilote.id AND MONTH(date_vol) = MONTH(DATE_SUB(curdate(), INTERVAL %d MONTH)) AND YEAR(date_vol) = YEAR(DATE_SUB(curdate(), INTERVAL %d MONTH))', $un_pilote->id, $offset_mois, $offset_mois);
			$resultatMois = $wpdb->get_results ($queryMois);
			$minutes = $resultatMois[0]->minutes;
			if ($minutes == null)
				$minutes = 0;
			$tot_pilote += $minutes;
			echo '<td align="center">' . $minutes . '</td>';
			$tot_col[$num_col] += $minutes;
			$num_col++;
			}
		$tot_col[$num_col] = $tot_pilote;
		echo '<td align="center">' . $tot_pilote . '</td></tr>';
		}
	$num_col = 0;
	echo '<tr><td>Total</td>';
	$tot_tot = 0;
	for ($minus_mois = $nb_mois; $minus_mois >= 0; $minus_mois--) {
		echo '<td align="center">' . $tot_col[$num_col] . '</td>';
		$tot_tot += $tot_col[$num_col];
		$num_col++;
		}
	echo '<td align="center">' . $tot_tot . '</td></tr>';
	echo '</table>';
}

// Affichage des fonctions deprecated
function display_deprecated() {
	echo '<center><font color="red"><h1>Fonction obsol&egrave;te,<br />voir manuel pour la remplacer.</h1></font></center>';
}

add_action('admin_menu', 'gd_carnet_menu');

// Page de saisie d'un vol
add_shortcode('carnet-vol-enregistre-vol', 'gd_carnet_ajoute_vol');
// Page d'affichage du carnet de vol du pilote connecté
add_shortcode('carnet-vol-pilote', 'gd_carnet_display_carnet_pilote');
// Page d'affichage des comptes et soldes des pilotes (pouvoir listAll pour voir les comptes des autres pilotes, pouvoir tresorier pour ajouter des débits / crédits)
add_shortcode('gestion-soldes-pilote', 'gd_carnet_gestion_liste_soldes_pilote');
// Page d'affichage du carnet de vol de l'ULM passé en paramètre (ulm=id_de_l_ulm)
add_shortcode('carnet-vol-ulm', 'gd_carnet_display_carnet_ulm');
// Page de saisie d'un entretien d'un ULM
add_shortcode('carnet-vol-enregistre-entretien', 'gd_carnet_ajoute_entretien');
// Page d'affichage du carnet d'entretien de l'ULM passé en paramètre (ulm=id_de_l_ulm)
add_shortcode('carnet-entretien-ulm', 'gd_carnet_display_entretien_ulm');
// Page de saisie d'une note de frais
add_shortcode('carnet-vol-enregistre-frais', 'gd_carnet_ajoute_frais');
// Page de liste des notes de frais
add_shortcode('carnet-vol-liste-frais', 'gd_carnet_liste_frais');
// Page d'affichage du nombre d'heures de vol mois par mois
add_shortcode('carnet-vol-heures-pilotes', 'gd_carnet_heures_pilotes');

// Les shortcodes deprecated
// Page d'affichage du compte du pilote connecté (DEPRECATED : fusionné avec gestion-soldes-pilote)
//add_shortcode('compte-pilote', 'display_deprecated');
// Page d'affichage de la liste des pilotes et de leurs soldes (affichage seulement) (DEPRECATED : fusionné avec gestion-soldes-pilote)
//add_shortcode('liste-soldes-pilote', 'display_deprecated');

// Enregistre un champ de réglage dans la base de données
function gd_carnet_register_settings() {
    register_setting( 'geo_account_settings', 'geo_account_enable_multi' );
}
add_action( 'admin_init', 'gd_carnet_register_settings' );
add_action('template_redirect', 'before_template');
